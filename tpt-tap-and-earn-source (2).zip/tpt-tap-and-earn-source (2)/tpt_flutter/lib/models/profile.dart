class Profile {
  const Profile({
    required this.id,
    required this.points,
    required this.createdAt,
    required this.isAdmin,
  });

  final String id;
  final int points;
  final DateTime createdAt;
  final bool isAdmin;

  factory Profile.fromMap(Map<String, dynamic> map) {
    return Profile(
      id: map['id'] as String,
      points: (map['points'] as num?)?.toInt() ?? 0,
      createdAt: DateTime.parse(map['created_at'] as String),
      isAdmin: map['is_admin'] as bool? ?? false,
    );
  }
}