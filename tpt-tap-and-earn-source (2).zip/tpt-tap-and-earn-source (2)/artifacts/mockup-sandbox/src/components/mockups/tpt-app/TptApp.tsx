import { useEffect, useMemo, useState } from "react";
import {
  ArrowRight,
  Check,
  ChevronRight,
  Cloud,
  Clock3,
  Coins,
  Eye,
  EyeOff,
  House,
  ListChecks,
  LogOut,
  Mail,
  Newspaper,
  Plus,
  ShieldCheck,
  Sparkles,
  Star,
  Touchpad,
  UserRound,
  UsersRound,
  X,
} from "lucide-react";

type View = "home" | "team" | "mine" | "admin" | "withdraw";
type AuthMode = "login" | "signup";
type WithdrawStatus = "pending" | "approved" | "paid";
type WithdrawMethod = {
  code: string;
  label: string;
};
type WithdrawRequest = {
  id: string;
  methodCode: string;
  accountNumber: string;
  amountPkr: number;
  status: WithdrawStatus;
  createdAt: string;
};

const STORAGE_KEY = "tpt-canvas-demo";
const withdrawMethods: WithdrawMethod[] = [
  { code: "jazzcash", label: "JazzCash" },
  { code: "easypaisa", label: "Easypaisa" },
];
const newsItems = [
  {
    category: "TPT UPDATE",
    title: "Every tap now counts toward your daily goal",
    summary: "Keep your momentum going and check in each day to grow your points.",
    date: "Today",
    icon: Sparkles,
  },
  {
    category: "COMMUNITY",
    title: "Welcome to the TPT community",
    summary: "Invite friends, complete tasks, and build your points together.",
    date: "Yesterday",
    icon: UsersRound,
  },
  {
    category: "TIP OF THE DAY",
    title: "Small habits create bigger rewards",
    summary: "A few consistent taps every day can turn into a strong weekly streak.",
    date: "2 days ago",
    icon: Star,
  },
] as const;

const teamMembers = [
  { name: "Alex Morgan", role: "Team lead", points: 128, initials: "AM" },
  { name: "Sam Lee", role: "Active member", points: 96, initials: "SL" },
  { name: "Jordan Kim", role: "Active member", points: 74, initials: "JK" },
  { name: "Taylor Reed", role: "New member", points: 42, initials: "TR" },
] as const;

type DemoState = {
  authenticated: boolean;
  email: string;
  points: number;
  sessionTaps: number;
  lastTapAt: string | null;
  withdrawRequests: WithdrawRequest[];
  isAdmin: boolean;
};

const seedState: DemoState = {
  authenticated: true,
  email: "alex@example.com",
  points: 128,
  sessionTaps: 0,
  lastTapAt: null,
  isAdmin: true,
  withdrawRequests: [
    {
      id: "demo-withdrawal-1",
      methodCode: "jazzcash",
      accountNumber: "03001234567",
      amountPkr: 500,
      status: "pending",
      createdAt: "2026-08-03T10:30:00.000Z",
    },
  ],
};

function readState(): DemoState {
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved) return { ...seedState, ...JSON.parse(saved) };
  } catch {
    // The preview still works when storage is unavailable.
  }
  return seedState;
}

function saveState(state: DemoState) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Storage is an enhancement for the preview, not a blocker.
  }
}

function formatTime(value: string | null) {
  if (!value) return "Ready when you are";
  const date = new Date(value);
  return `Last tap at ${date.toLocaleTimeString([], {
    hour: "numeric",
    minute: "2-digit",
  })}`;
}

export function TptApp() {
  const [demo, setDemo] = useState<DemoState>(() => readState());
  const [view, setView] = useState<View>("home");
  const [authMode, setAuthMode] = useState<AuthMode>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isTapping, setIsTapping] = useState(false);
  const [coinBurst, setCoinBurst] = useState(0);
  const [completedTasks, setCompletedTasks] = useState([true, false, false]);
  const [withdrawMethod, setWithdrawMethod] = useState(withdrawMethods[0].code);
  const [withdrawAccount, setWithdrawAccount] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [isSubmittingWithdrawal, setIsSubmittingWithdrawal] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    saveState(demo);
  }, [demo]);

  const firstName = useMemo(() => {
    const name = demo.email.split("@")[0]?.replace(/[._-]/g, " ") || "there";
    return name.charAt(0).toUpperCase() + name.slice(1);
  }, [demo.email]);

  const initials = firstName.slice(0, 2).toUpperCase();

  function submitAuth(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setNotice("");

    if (!email.includes("@")) {
      setError("Enter a valid email address.");
      return;
    }
    if (password.length < 6) {
      setError("Use at least 6 characters for your password.");
      return;
    }

    setIsSubmitting(true);
    window.setTimeout(() => {
      const nextEmail = email.trim().toLowerCase();
      setDemo((current) => ({
        ...current,
        authenticated: true,
        email: nextEmail,
      }));
      setIsSubmitting(false);
      setNotice(
        authMode === "signup"
          ? "Account created. Your points are ready."
          : "Welcome back. Your points are synced.",
      );
      setEmail("");
      setPassword("");
    }, 450);
  }

  function tap() {
    if (isTapping) return;
    setError("");
    setNotice("");
    setIsTapping(true);
    window.setTimeout(() => {
      setDemo((current) => ({
        ...current,
        points: current.points + 1,
        sessionTaps: current.sessionTaps + 1,
        lastTapAt: new Date().toISOString(),
      }));
      setCoinBurst((current) => current + 1);
      setIsTapping(false);
      setNotice("Coin saved to your cloud profile.");
    }, 180);
  }

  function signOut() {
    setDemo((current) => ({ ...current, authenticated: false }));
    setView("home");
    setNotice("");
    setError("");
  }

  function submitWithdrawal(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setNotice("");
    const account = withdrawAccount.trim();
    const amount = Number.parseInt(withdrawAmount.trim(), 10);
    if (!/^[0-9]{8,20}$/.test(account)) {
      setError("Enter a valid account number using 8 to 20 digits.");
      return;
    }
    if (!Number.isInteger(amount) || amount < 500) {
      setError("Minimum withdrawal is 500 PKR.");
      return;
    }
    if (amount > demo.points) {
      setError("You do not have enough coins for this withdrawal.");
      return;
    }

    setIsSubmittingWithdrawal(true);
    window.setTimeout(() => {
      setDemo((current) => ({
        ...current,
        withdrawRequests: [
          {
            id: `withdraw-${Date.now()}`,
            methodCode: withdrawMethod,
            accountNumber: account,
            amountPkr: amount,
            status: "pending",
            createdAt: new Date().toISOString(),
          },
          ...current.withdrawRequests,
        ],
      }));
      setWithdrawAccount("");
      setWithdrawAmount("");
      setIsSubmittingWithdrawal(false);
      setNotice("Withdrawal request submitted for admin review.");
    }, 300);
  }

  function advanceWithdrawal(request: WithdrawRequest) {
    const nextStatus: WithdrawStatus = request.status === "pending" ? "approved" : "paid";
    setDemo((current) => ({
      ...current,
      points: request.status === "pending" ? current.points - request.amountPkr : current.points,
      withdrawRequests: current.withdrawRequests.map((item) =>
        item.id === request.id ? { ...item, status: nextStatus } : item,
      ),
    }));
    setNotice(nextStatus === "approved"
      ? "Request approved and coins deducted."
      : "Request marked as paid.");
  }

  if (!demo.authenticated) {
    return (
      <main className="min-h-screen bg-[#eff8f4] text-[#132724]">
        <div className="relative flex min-h-screen items-center justify-center overflow-hidden px-5 py-10">
          <div className="pointer-events-none absolute -left-28 -top-28 h-80 w-80 rounded-full bg-[#c8f3e5] blur-3xl" />
          <div className="pointer-events-none absolute -bottom-32 -right-24 h-96 w-96 rounded-full bg-[#dbeee6] blur-3xl" />
          <section className="relative grid w-full max-w-5xl overflow-hidden rounded-[32px] border border-white/80 bg-white/80 shadow-[0_30px_100px_rgba(20,75,61,0.13)] backdrop-blur-xl md:grid-cols-[0.92fr_1.08fr]">
            <div className="relative hidden overflow-hidden bg-[#123b35] p-10 text-white md:flex md:flex-col md:justify-between">
              <div className="absolute -right-20 top-20 h-64 w-64 rounded-full border-[32px] border-[#2eb89b]/25" />
              <div className="absolute -bottom-32 -left-20 h-72 w-72 rounded-full bg-[#2eb89b]/15" />
              <Brand dark />
              <div className="relative">
                <p className="mb-4 text-xs font-bold uppercase tracking-[0.22em] text-[#9be8d5]">
                  One tap at a time
                </p>
                <h1 className="max-w-sm text-5xl font-black leading-[0.98] tracking-[-0.05em]">
                  Make every tap count.
                </h1>
                <p className="mt-6 max-w-xs text-sm leading-6 text-[#c7e5dc]">
                  A tiny daily ritual with a visible reward. Your points stay
                  synced wherever you go.
                </p>
              </div>
              <div className="relative flex items-center gap-3 text-xs text-[#a9d8ce]">
                <Cloud className="h-4 w-4" />
                <span>Cloud-saved with Supabase</span>
              </div>
            </div>

            <div className="flex min-h-[680px] flex-col justify-center p-7 sm:p-12">
              <div className="md:hidden">
                <Brand />
                <div className="mt-8" />
              </div>
              <div className="max-w-md">
                <div className="mb-8">
                  <p className="mb-2 text-sm font-semibold text-[#149a7f]">
                    {authMode === "login" ? "Welcome back" : "Start earning"}
                  </p>
                  <h2 className="text-4xl font-black tracking-[-0.05em] text-[#132724]">
                    {authMode === "login"
                      ? "Ready for your next point?"
                      : "Build your point streak."}
                  </h2>
                  <p className="mt-3 text-sm leading-6 text-[#70817b]">
                    {authMode === "login"
                      ? "Log in to pick up exactly where you left off."
                      : "Create your account and make every tap count."}
                  </p>
                </div>
                <form className="space-y-4" onSubmit={submitAuth}>
                  <label className="block">
                    <span className="mb-2 block text-xs font-bold uppercase tracking-[0.14em] text-[#71837c]">
                      Email address
                    </span>
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8ca19a]" />
                      <input
                        aria-label="Email address"
                        autoComplete="email"
                        className="h-14 w-full rounded-2xl border border-[#dce9e3] bg-[#f9fcfa] pl-11 pr-4 text-sm outline-none transition focus:border-[#18ad91] focus:ring-4 focus:ring-[#18ad91]/10"
                        onChange={(event) => setEmail(event.target.value)}
                        placeholder="you@example.com"
                        type="email"
                        value={email}
                      />
                    </div>
                  </label>
                  <label className="block">
                    <span className="mb-2 block text-xs font-bold uppercase tracking-[0.14em] text-[#71837c]">
                      Password
                    </span>
                    <div className="relative">
                      <ShieldCheck className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8ca19a]" />
                      <input
                        aria-label="Password"
                        autoComplete={
                          authMode === "login" ? "current-password" : "new-password"
                        }
                        className="h-14 w-full rounded-2xl border border-[#dce9e3] bg-[#f9fcfa] pl-11 pr-12 text-sm outline-none transition focus:border-[#18ad91] focus:ring-4 focus:ring-[#18ad91]/10"
                        onChange={(event) => setPassword(event.target.value)}
                        placeholder="At least 6 characters"
                        type={showPassword ? "text" : "password"}
                        value={password}
                      />
                      <button
                        aria-label={showPassword ? "Hide password" : "Show password"}
                        className="absolute right-3 top-1/2 -translate-y-1/2 rounded-xl p-2 text-[#789089] transition hover:bg-[#eaf5f0] hover:text-[#149a7f]"
                        onClick={() => setShowPassword((current) => !current)}
                        type="button"
                      >
                        {showPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </button>
                    </div>
                  </label>
                  {error && <Feedback kind="error" message={error} />}
                  {notice && <Feedback kind="success" message={notice} />}
                  <button
                    className="group flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-[#16aa8e] font-bold text-white shadow-[0_12px_25px_rgba(22,170,142,0.24)] transition hover:-translate-y-0.5 hover:bg-[#11977d] disabled:cursor-wait disabled:opacity-60"
                    disabled={isSubmitting}
                    type="submit"
                  >
                    {isSubmitting ? "Connecting..." : authMode === "login" ? "Log in" : "Create account"}
                    {!isSubmitting && <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />}
                  </button>
                </form>
                <div className="my-7 flex items-center gap-3 text-xs text-[#96a59f]">
                  <span className="h-px flex-1 bg-[#e4eee9]" />
                  <span>secure email access</span>
                  <span className="h-px flex-1 bg-[#e4eee9]" />
                </div>
                <button
                  className="w-full text-center text-sm font-semibold text-[#149a7f] transition hover:text-[#0d6e5c]"
                  onClick={() => {
                    setAuthMode((current) => (current === "login" ? "signup" : "login"));
                    setError("");
                    setNotice("");
                  }}
                  type="button"
                >
                  {authMode === "login"
                    ? "New here? Create an account"
                    : "Already have an account? Log in"}
                </button>
              </div>
            </div>
          </section>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[#eff8f4] text-[#132724]">
      <div className="mx-auto flex min-h-screen w-full max-w-[1180px] flex-col px-5 py-5 sm:px-8 sm:py-8">
        <header className="flex items-center justify-between">
          <Brand />
          <button
            aria-label="Sign out"
            className="flex items-center gap-2 rounded-full border border-[#d8e9e2] bg-white/70 px-3 py-2 text-xs font-bold text-[#60756d] transition hover:border-[#f0caca] hover:bg-white hover:text-[#bb5555]"
            onClick={signOut}
            type="button"
          >
            <LogOut className="h-4 w-4" />
            <span className="hidden sm:inline">Sign out</span>
          </button>
        </header>

        <div className="flex-1 pb-28 pt-9">
          {view === "home" ? (
            <section className="mx-auto max-w-4xl">
              <div className="mb-8 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
                <div>
                  <p className="mb-2 text-sm font-medium text-[#71837c]">
                    {new Date().toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" })}
                  </p>
                  <h1 className="text-4xl font-black tracking-[-0.06em] sm:text-5xl">
                    Hey, {firstName}.
                  </h1>
                  <p className="mt-3 text-sm text-[#70817b]">
                    Keep the momentum going.
                  </p>
                </div>
                <div className="flex items-center gap-2 rounded-full border border-[#d7ebe3] bg-white/70 px-3 py-2 text-xs font-semibold text-[#598076]">
                  <Cloud className="h-4 w-4 text-[#18a98d]" />
                  Points synced
                  <span className="h-2 w-2 rounded-full bg-[#24c39f]" />
                </div>
              </div>

              <div className="grid gap-5 lg:grid-cols-[1fr_1.4fr]">
                <div className="relative overflow-hidden rounded-[30px] bg-[#123b35] p-7 text-white shadow-[0_24px_60px_rgba(15,73,60,0.18)] sm:p-8">
                  <div className="absolute -right-16 -top-16 h-48 w-48 rounded-full border-[22px] border-[#43c5a8]/20" />
                  <div className="absolute -bottom-28 -left-20 h-56 w-56 rounded-full bg-[#42c3a6]/10" />
                  <div className="relative flex h-full min-h-[250px] flex-col justify-between">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-[#a9d9ce]">
                           Total coins
                        </p>
                        <p className="mt-2 text-6xl font-black tracking-[-0.07em]">
                          {demo.points}
                        </p>
                      </div>
                      <div className="rounded-2xl bg-white/10 p-3">
                        <Star className="h-6 w-6 fill-[#a9efdc] text-[#a9efdc]" />
                      </div>
                    </div>
                    <div className="flex items-end justify-between">
                      <div>
                        <p className="text-xs text-[#a9d9ce]">This session</p>
                        <p className="mt-1 text-2xl font-extrabold text-[#bdf6e8]">
                          +{demo.sessionTaps}
                        </p>
                      </div>
                      <p className="text-right text-xs text-[#a9d9ce]">
                        {formatTime(demo.lastTapAt)}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="relative flex min-h-[360px] flex-col items-center justify-center overflow-hidden rounded-[30px] border border-white bg-white/80 p-7 shadow-[0_20px_60px_rgba(31,90,73,0.08)]">
                  <div className="pointer-events-none absolute left-8 top-8 h-20 w-20 rounded-full bg-[#d9f5eb]" />
                  <div className="pointer-events-none absolute bottom-5 right-8 h-28 w-28 rounded-full bg-[#e7f5ef]" />
                  <div className="relative mb-7 text-center">
                    <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#18a98d]">
                      Make it count
                    </p>
                    <h2 className="mt-2 text-2xl font-black tracking-[-0.04em]">
                      One tap, one point.
                    </h2>
                  </div>
                  <div className="relative z-10">
                    {coinBurst > 0 && (
                      <div
                        className="pointer-events-none absolute -top-2 left-1/2 z-20 -translate-x-1/2 whitespace-nowrap rounded-2xl bg-[#fff3d6] px-3 py-2 text-xs font-black tracking-[0.05em] text-[#8f6412] shadow-[0_8px_20px_rgba(44,122,104,0.2)]"
                        key={coinBurst}
                        style={{ animation: "tpt-coin-float 820ms ease-out forwards" }}
                      >
                        <span className="mr-1.5 inline-block text-sm">●</span>
                        +1 COIN
                      </div>
                    )}
                    <button
                      aria-label="Tap to earn one coin"
                      className={`group relative flex h-48 w-48 flex-col items-center justify-center rounded-full bg-[#17b99b] text-white shadow-[0_0_0_16px_rgba(23,185,155,0.08),0_20px_40px_rgba(23,185,155,0.32)] transition duration-150 hover:bg-[#10a88c] hover:shadow-[0_0_0_22px_rgba(23,185,155,0.08),0_22px_48px_rgba(23,185,155,0.38)] active:scale-95 ${isTapping ? "scale-95" : ""}`}
                      onClick={tap}
                      type="button"
                    >
                      <Touchpad className="mb-2 h-10 w-10 transition group-hover:scale-110" />
                      <span className="text-3xl font-black tracking-[0.08em]">TAP</span>
                      <span className="mt-1 text-[10px] font-bold tracking-[0.18em] text-[#c7fff2]">
                        +1 COIN
                      </span>
                    </button>
                  </div>
                  <style>{`
                    @keyframes tpt-coin-float {
                      0% { opacity: 0; transform: translate(-50%, 18px) scale(.72); }
                      18% { opacity: 1; transform: translate(-50%, 0) scale(1.08); }
                      58% { opacity: 1; transform: translate(-50%, -20px) scale(1); }
                      100% { opacity: 0; transform: translate(-50%, -54px) scale(.96); }
                    }
                  `}</style>
                  <p className="relative mt-7 text-center text-xs text-[#788b84]">
                     {notice || "Your coin is saved instantly to your profile."}
                  </p>
                </div>
              </div>

              <div className="mt-5 flex items-center justify-between rounded-2xl border border-[#dcece5] bg-white/55 px-5 py-4">
                <div className="flex items-center gap-3">
                  <div className="rounded-xl bg-[#dff6ee] p-2 text-[#149a7f]">
                    <Sparkles className="h-4 w-4" />
                  </div>
                  <div>
                    <p className="text-sm font-bold">Your points are yours</p>
                    <p className="text-xs text-[#778a82]">Synced across sessions with Supabase.</p>
                  </div>
                </div>
                <ChevronRight className="h-4 w-4 text-[#8ca29a]" />
              </div>
              <button
                className="mt-4 flex w-full items-center justify-between rounded-2xl border border-[#bce9dc] bg-[#e9faf3] px-5 py-4 text-left transition hover:bg-[#def6ed]"
                onClick={() => {
                  setCompletedTasks((current) => current.map((done, index) => index === 1 ? !done : done));
                  setNotice("Daily task progress updated.");
                }}
                type="button"
              >
                <span className="flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#18a98d] text-white">
                    <ListChecks className="h-5 w-5" />
                  </span>
                  <span>
                    <span className="block text-sm font-black">Daily task</span>
                    <span className="mt-1 block text-xs text-[#5e8176]">
                      {completedTasks[1] ? "Completed · +5 coins" : "Tap 5 times today · +5 coins"}
                    </span>
                  </span>
                </span>
                <ArrowRight className="h-4 w-4 text-[#149a7f]" />
              </button>
            </section>
          ) : view === "team" ? (
            <TeamPage />
          ) : view === "mine" ? (
            <section className="mx-auto max-w-2xl">
              <div className="mb-9">
                <p className="mb-2 text-sm font-semibold text-[#149a7f]">Your account</p>
                <h1 className="text-4xl font-black tracking-[-0.06em] sm:text-5xl">Profile.</h1>
                <p className="mt-3 text-sm text-[#70817b]">Everything about your TPT progress, in one place.</p>
              </div>
              <div className="rounded-[30px] border border-white bg-white/80 p-7 shadow-[0_20px_60px_rgba(31,90,73,0.08)] sm:p-9">
                <div className="flex flex-col items-center border-b border-[#e8f0ec] pb-8 text-center sm:flex-row sm:text-left">
                  <div className="flex h-20 w-20 items-center justify-center rounded-[26px] bg-[#123b35] text-2xl font-black text-[#bdf6e8]">
                    {initials}
                  </div>
                  <div className="mt-4 sm:ml-5 sm:mt-0">
                    <p className="text-xl font-black tracking-[-0.03em]">{firstName}</p>
                    <p className="mt-1 flex items-center justify-center gap-1.5 text-sm text-[#70817b] sm:justify-start">
                      <Mail className="h-3.5 w-3.5" />
                      {demo.email}
                    </p>
                  </div>
                  <div className="mt-4 flex items-center gap-1.5 rounded-full bg-[#e6f8f1] px-3 py-1.5 text-[11px] font-bold text-[#149a7f] sm:ml-auto sm:mt-0">
                    <Check className="h-3.5 w-3.5" />
                    Verified
                  </div>
                </div>
                <div className="grid gap-4 py-8 sm:grid-cols-2">
                  <div className="rounded-2xl bg-[#f3faf7] p-5">
                     <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#7e9189]">Total earning</p>
                    <p className="mt-2 text-4xl font-black tracking-[-0.05em] text-[#149a7f]">{demo.points}</p>
                  </div>
                  <div className="rounded-2xl bg-[#f3faf7] p-5">
                    <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-[#7e9189]">Session taps</p>
                    <p className="mt-2 text-4xl font-black tracking-[-0.05em] text-[#123b35]">{demo.sessionTaps}</p>
                  </div>
                </div>
                <div className="mt-4 flex items-center gap-4 rounded-2xl border border-[#e8e5d6] bg-[#fffdf5] p-5">
                  <div className="rounded-2xl bg-[#fff1c7] p-3 text-[#b47b14]">
                    <Coins className="h-6 w-6" />
                  </div>
                  <div className="flex-1">
                    <p className="text-base font-black">Wallet</p>
                   <p className="mt-1 text-xs text-[#70817b]">Your available TPT coin balance</p>
                  </div>
                  <p className="text-2xl font-black text-[#149a7f]">{demo.points}</p>
                </div>
                 <button
                   className="mt-4 flex w-full items-center gap-4 rounded-2xl border border-[#dcefe7] bg-[#f7fcf9] p-5 text-left transition hover:border-[#9edecb] hover:bg-white"
                   onClick={() => {
                     setView("withdraw");
                     setError("");
                     setNotice("");
                   }}
                   type="button"
                 >
                   <div className="rounded-2xl bg-[#e1f7ef] p-3 text-[#149a7f]">
                     <ArrowRight className="h-6 w-6" />
                   </div>
                   <div className="min-w-0 flex-1">
                     <p className="text-base font-black">Withdraw funds</p>
                     <p className="mt-1 text-xs text-[#70817b]">
                       JazzCash and Easypaisa · minimum 500 PKR
                     </p>
                   </div>
                   <ChevronRight className="h-5 w-5 text-[#8ca29a]" />
                 </button>
                 <div className="mt-4 rounded-2xl border border-[#e8f0ec] bg-white/65 p-5">
                   <div className="mb-4 flex items-center justify-between">
                     <div>
                       <p className="text-sm font-black">Withdraw History</p>
                       <p className="mt-1 text-xs text-[#778a82]">Your latest payout requests</p>
                     </div>
                     <Clock3 className="h-5 w-5 text-[#149a7f]" />
                   </div>
                   <div className="space-y-2">
                     {demo.withdrawRequests.slice(0, 2).map((request) => (
                       <WithdrawRequestCard key={request.id} request={request} compact />
                     ))}
                   </div>
                 </div>
                <div className="flex items-start gap-3 rounded-2xl border border-[#dcefe7] bg-[#f7fcf9] p-4">
                  <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-[#18a98d]" />
                  <div>
                    <p className="text-sm font-bold">Cloud points are on</p>
                    <p className="mt-1 text-xs leading-5 text-[#71837c]">
                      Your points are tied to your account and stay safe across sessions.
                    </p>
                  </div>
                </div>
                <button
                  className="mt-7 flex h-13 w-full items-center justify-center gap-2 rounded-2xl border border-[#f0d3d3] py-3 text-sm font-bold text-[#bd5e5e] transition hover:bg-[#fff7f7]"
                  onClick={signOut}
                  type="button"
                >
                  <LogOut className="h-4 w-4" />
                  Sign out of TPT
                </button>
              </div>
            </section>
           ) : view === "withdraw" ? (
             <WithdrawPage
               points={demo.points}
               requests={demo.withdrawRequests}
               method={withdrawMethod}
               account={withdrawAccount}
               amount={withdrawAmount}
               isSubmitting={isSubmittingWithdrawal}
               error={error}
               notice={notice}
               onMethodChange={setWithdrawMethod}
               onAccountChange={setWithdrawAccount}
               onAmountChange={setWithdrawAmount}
               onSubmit={submitWithdrawal}
               onBack={() => {
                 setView("mine");
                 setError("");
                 setNotice("");
               }}
             />
           ) : view === "admin" ? (
             <AdminPage
               isAdmin={demo.isAdmin}
               requests={demo.withdrawRequests}
               onAdvance={advanceWithdrawal}
             />
          ) : (
             <TeamPage />
          )}
        </div>

        <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-[#d9ebe4] bg-white/95 px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-2 shadow-[0_-12px_30px_rgba(31,90,73,0.08)] backdrop-blur-md">
          <div className="mx-auto flex w-full max-w-xl items-stretch justify-between gap-1">
             <NavButton active={view === "home"} icon={<House className="h-5 w-5" />} label="Home" onClick={() => setView("home")} />
             <NavButton active={view === "team"} icon={<UsersRound className="h-5 w-5" />} label="Team" onClick={() => setView("team")} />
             <NavButton active={view === "mine" || view === "withdraw"} icon={<UserRound className="h-5 w-5" />} label="Mine" onClick={() => setView("mine")} />
             <NavButton active={view === "admin"} icon={<ShieldCheck className="h-5 w-5" />} label="Admin" onClick={() => setView("admin")} />
          </div>
        </nav>
      </div>
    </main>
  );
}

function Brand({ dark = false }: { dark?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <div className={`flex h-10 w-10 items-center justify-center rounded-[14px] ${dark ? "bg-[#20b494]" : "bg-[#17b99b]"} shadow-[0_8px_18px_rgba(23,185,155,0.2)]`}>
        <Touchpad className="h-5 w-5 text-white" />
      </div>
      <div>
        <p className={`text-lg font-black tracking-[0.15em] ${dark ? "text-white" : "text-[#123b35]"}`}>TPT</p>
        <p className={`text-[9px] font-bold uppercase tracking-[0.18em] ${dark ? "text-[#a9d9ce]" : "text-[#7d928a]"}`}>Tap & Earn</p>
      </div>
    </div>
  );
}

function Feedback({ kind, message }: { kind: "error" | "success"; message: string }) {
  return (
    <div className={`flex items-start gap-2 rounded-2xl px-4 py-3 text-xs leading-5 ${kind === "error" ? "bg-[#fff3f3] text-[#b75252]" : "bg-[#e9faf3] text-[#147b68]"}`}>
      {kind === "error" ? <X className="mt-0.5 h-4 w-4 shrink-0" /> : <Check className="mt-0.5 h-4 w-4 shrink-0" />}
      <span>{message}</span>
    </div>
  );
}

function NewsPage() {
  return (
    <section className="mx-auto max-w-2xl">
      <PageHeading eyebrow="Latest from TPT" title="News." description="Updates, tips, and community news for your earning journey." />
      <div className="space-y-3">
        {newsItems.map((item) => {
          const Icon = item.icon;
          return (
            <article className="flex gap-4 rounded-[24px] border border-white bg-white/80 p-5 shadow-[0_16px_35px_rgba(31,90,73,0.06)]" key={item.title}>
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-[#e1f7ef] text-[#149a7f]">
                <Icon className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] font-black tracking-[0.18em] text-[#149a7f]">{item.category}</p>
                <h2 className="mt-1 text-base font-black">{item.title}</h2>
                <p className="mt-1 text-sm leading-5 text-[#70817b]">{item.summary}</p>
                <p className="mt-3 flex items-center gap-1 text-xs font-semibold text-[#9aa9a3]">
                  <Clock3 className="h-3 w-3" /> {item.date}
                </p>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}

function TaskPage({
  completedTasks,
  onToggle,
}: {
  completedTasks: boolean[];
  onToggle: (index: number) => void;
}) {
  const tasks = [
    { title: "Complete your first tap", summary: "Tap once to start earning points.", reward: 1, icon: Touchpad },
    { title: "Tap five times today", summary: "Build a simple daily earning habit.", reward: 5, icon: Sparkles },
    { title: "Invite a friend", summary: "Grow the TPT community together.", reward: 10, icon: Plus },
  ];
  const completed = completedTasks.filter(Boolean).length;

  return (
    <section className="mx-auto max-w-2xl">
      <PageHeading eyebrow="Daily rewards" title="Tasks." description="Complete tasks to unlock extra rewards." />
      <div className="mb-5 flex items-center gap-3 rounded-[24px] bg-[#149a7f] p-5 text-white">
        <ListChecks className="h-7 w-7" />
        <p className="flex-1 font-black">{completed} of {tasks.length} tasks complete</p>
        <p className="text-xl font-black">{Math.round((completed / tasks.length) * 100)}%</p>
      </div>
      <div className="space-y-3">
        {tasks.map((task, index) => {
          const Icon = task.icon;
          return (
            <button
              className="flex w-full items-center gap-3 rounded-[22px] border border-white bg-white/80 p-4 text-left shadow-[0_14px_30px_rgba(31,90,73,0.05)]"
              key={task.title}
              onClick={() => onToggle(index)}
              type="button"
            >
              <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 ${completedTasks[index] ? "border-[#149a7f] bg-[#149a7f] text-white" : "border-[#b9c9c1] text-transparent"}`}>
                <Check className="h-3.5 w-3.5" />
              </span>
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#e1f7ef] text-[#149a7f]">
                <Icon className="h-4 w-4" />
              </span>
              <span className="min-w-0 flex-1">
                <span className={`block text-sm font-black ${completedTasks[index] ? "text-[#71837c] line-through" : ""}`}>{task.title}</span>
                <span className="mt-1 block text-xs leading-5 text-[#778a82]">{task.summary}</span>
              </span>
              <span className="text-sm font-black text-[#149a7f]">+{task.reward}</span>
            </button>
          );
        })}
      </div>
    </section>
  );
}

function TeamPage() {
  const levels = [
    { label: "A-Level", count: 4, earning: 1280, icon: Star },
    { label: "B-Level", count: 12, earning: 760, icon: UsersRound },
    { label: "C-Level", count: 28, earning: 420, icon: UsersRound },
  ];

  return (
    <section className="mx-auto max-w-2xl">
      <PageHeading eyebrow="Community" title="Your team." description="Track A-Level, B-Level, and C-Level members and earnings." />
      <div className="mb-5 flex items-center gap-4 rounded-[24px] bg-[#123b35] p-5 text-white">
        <UsersRound className="h-7 w-7 text-[#b6f7e8]" />
        <div>
          <p className="text-xl font-black">44 members</p>
          <p className="mt-1 text-xs text-[#a9d9ce]">Growing your network</p>
        </div>
      </div>
      <div className="space-y-3">
        {levels.map((level) => {
          const Icon = level.icon;
          return (
            <div className="flex items-center gap-3 rounded-[22px] border border-white bg-white/80 p-5 shadow-[0_14px_30px_rgba(31,90,73,0.05)]" key={level.label}>
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#e1f7ef] text-[#149a7f]">
                <Icon className="h-5 w-5" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-black">{level.label}</p>
                <p className="mt-1 text-xs text-[#778a82]">{level.count} members</p>
              </div>
              <div className="text-right">
                <p className="text-lg font-black text-[#149a7f]">{level.earning} PKR</p>
                <p className="text-[10px] text-[#8a9892]">earning</p>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

function AdminPage({
  isAdmin,
  requests,
  onAdvance,
}: {
  isAdmin: boolean;
  requests: WithdrawRequest[];
  onAdvance: (request: WithdrawRequest) => void;
}) {
  const pending = requests.filter((request) => request.status === "pending").length;

  if (!isAdmin) {
    return (
      <section className="mx-auto max-w-2xl">
        <PageHeading eyebrow="Restricted" title="Admin." description="Withdrawal management is available to approved admins only." />
        <div className="rounded-[28px] border border-white bg-white/80 p-8 text-center shadow-[0_20px_60px_rgba(31,90,73,0.08)]">
          <ShieldCheck className="mx-auto h-10 w-10 text-[#8da29a]" />
          <p className="mt-4 text-sm font-black">Admin access required</p>
        </div>
      </section>
    );
  }

  return (
    <section className="mx-auto max-w-2xl">
      <PageHeading eyebrow="Operations" title="Admin." description="Review pending withdrawal requests and record completed payouts." />
      <div className="mb-5 flex items-center gap-4 rounded-[24px] bg-[#123b35] p-5 text-white">
        <ShieldCheck className="h-7 w-7 text-[#b6f7e8]" />
        <div>
          <p className="text-xl font-black">{pending} pending requests</p>
          <p className="mt-1 text-xs text-[#a9d9ce]">Approve to deduct coins atomically</p>
        </div>
      </div>
      <div className="space-y-3">
        {requests.map((request) => {
          const method = withdrawMethods.find((item) => item.code === request.methodCode);
          const isPending = request.status === "pending";
          const isPaid = request.status === "paid";
          return (
            <div className="rounded-[22px] border border-white bg-white/80 p-5 shadow-[0_14px_30px_rgba(31,90,73,0.05)]" key={request.id}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-black">{method?.label ?? request.methodCode}</p>
                  <p className="mt-1 text-xs text-[#778a82]">Account •••• {request.accountNumber.slice(-4)}</p>
                </div>
                <p className="text-base font-black">{request.amountPkr} PKR</p>
              </div>
              <div className="mt-4 flex items-center justify-between gap-3">
                <span className={`rounded-full px-2.5 py-1 text-[10px] font-black ${
                  isPaid ? "bg-[#e6f8f1] text-[#168c70]" : isPending ? "bg-[#fff4d5] text-[#b47b14]" : "bg-[#edf3ff] text-[#3e6fc0]"
                }`}>
                  {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                </span>
                {!isPaid && (
                  <button
                    className="rounded-xl border border-[#b9ded2] px-3 py-2 text-xs font-black text-[#149a7f] transition hover:bg-[#e9faf3]"
                    onClick={() => onAdvance(request)}
                    type="button"
                  >
                    {isPending ? "Approve" : "Mark paid"}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

function WithdrawPage({
  points,
  requests,
  method,
  account,
  amount,
  isSubmitting,
  error,
  notice,
  onMethodChange,
  onAccountChange,
  onAmountChange,
  onSubmit,
  onBack,
}: {
  points: number;
  requests: WithdrawRequest[];
  method: string;
  account: string;
  amount: string;
  isSubmitting: boolean;
  error: string;
  notice: string;
  onMethodChange: (value: string) => void;
  onAccountChange: (value: string) => void;
  onAmountChange: (value: string) => void;
  onSubmit: (event: React.FormEvent<HTMLFormElement>) => void;
  onBack: () => void;
}) {
  return (
    <section className="mx-auto max-w-2xl">
      <button
        className="mb-5 flex items-center gap-2 text-sm font-bold text-[#149a7f] transition hover:text-[#0d6e5c]"
        onClick={onBack}
        type="button"
      >
        <ArrowRight className="h-4 w-4 rotate-180" />
        Back to Mine
      </button>
      <PageHeading
        eyebrow="Wallet"
        title="Withdraw History."
        description="Request a payout and follow each step from admin review to paid."
      />
      <form
        className="rounded-[30px] border border-white bg-white/80 p-6 shadow-[0_20px_60px_rgba(31,90,73,0.08)] sm:p-8"
        onSubmit={onSubmit}
      >
        <div className="mb-5 flex items-center justify-between rounded-2xl bg-[#fff8e7] p-4">
          <div className="flex items-center gap-3">
            <Coins className="h-6 w-6 text-[#b47b14]" />
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.14em] text-[#9a7b3d]">Available coins</p>
              <p className="mt-1 text-2xl font-black text-[#9a6a10]">{points}</p>
            </div>
          </div>
          <p className="text-right text-xs leading-5 text-[#9a7b3d]">
            Minimum<br />500 PKR
          </p>
        </div>
        <label className="mb-4 block">
          <span className="mb-2 block text-xs font-bold uppercase tracking-[0.14em] text-[#71837c]">
            Withdrawal method
          </span>
          <select
            aria-label="Withdrawal method"
            className="h-14 w-full rounded-2xl border border-[#dce9e3] bg-[#f9fcfa] px-4 text-sm outline-none transition focus:border-[#18ad91] focus:ring-4 focus:ring-[#18ad91]/10"
            onChange={(event) => onMethodChange(event.target.value)}
            value={method}
          >
            {withdrawMethods.map((item) => (
              <option key={item.code} value={item.code}>{item.label}</option>
            ))}
          </select>
        </label>
        <label className="mb-4 block">
          <span className="mb-2 block text-xs font-bold uppercase tracking-[0.14em] text-[#71837c]">
            Account number
          </span>
          <input
            aria-label="Account number"
            className="h-14 w-full rounded-2xl border border-[#dce9e3] bg-[#f9fcfa] px-4 text-sm outline-none transition focus:border-[#18ad91] focus:ring-4 focus:ring-[#18ad91]/10"
            inputMode="numeric"
            maxLength={20}
            onChange={(event) => onAccountChange(event.target.value.replace(/\D/g, ""))}
            placeholder="e.g. 03001234567"
            value={account}
          />
        </label>
        <label className="mb-5 block">
          <span className="mb-2 block text-xs font-bold uppercase tracking-[0.14em] text-[#71837c]">
            Amount (PKR)
          </span>
          <input
            aria-label="Amount in PKR"
            className="h-14 w-full rounded-2xl border border-[#dce9e3] bg-[#f9fcfa] px-4 text-sm outline-none transition focus:border-[#18ad91] focus:ring-4 focus:ring-[#18ad91]/10"
            inputMode="numeric"
            min={500}
            onChange={(event) => onAmountChange(event.target.value.replace(/\D/g, ""))}
            placeholder="Minimum 500"
            type="number"
            value={amount}
          />
        </label>
        {error && <div className="mb-4"><Feedback kind="error" message={error} /></div>}
        {notice && <div className="mb-4"><Feedback kind="success" message={notice} /></div>}
        <button
          className="flex h-14 w-full items-center justify-center gap-2 rounded-2xl bg-[#16aa8e] font-bold text-white shadow-[0_12px_25px_rgba(22,170,142,0.24)] transition hover:-translate-y-0.5 hover:bg-[#11977d] disabled:cursor-wait disabled:opacity-60"
          disabled={isSubmitting}
          type="submit"
        >
          {isSubmitting ? "Submitting..." : "Request withdrawal"}
          {!isSubmitting && <ArrowRight className="h-4 w-4" />}
        </button>
        <p className="mt-4 text-center text-xs leading-5 text-[#778a82]">
          Coins are deducted only after admin approval. Requests stay pending until reviewed.
        </p>
      </form>
      <div className="mt-8">
        <h2 className="mb-3 text-xl font-black">Recent requests</h2>
        {requests.length === 0 ? (
          <div className="rounded-[24px] border border-white bg-white/75 p-7 text-center">
            <Clock3 className="mx-auto h-8 w-8 text-[#9aa9a3]" />
            <p className="mt-3 text-sm font-bold">No withdrawal requests yet</p>
            <p className="mt-1 text-xs text-[#778a82]">Your requests will appear here.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {requests.map((request) => (
              <WithdrawRequestCard key={request.id} request={request} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function WithdrawRequestCard({
  request,
  compact = false,
}: {
  request: WithdrawRequest;
  compact?: boolean;
}) {
  const method = withdrawMethods.find((item) => item.code === request.methodCode);
  const statusColor = request.status === "paid"
    ? "text-[#168c70] bg-[#e6f8f1]"
    : request.status === "approved"
      ? "text-[#3e6fc0] bg-[#edf3ff]"
      : "text-[#b47b14] bg-[#fff4d5]";
  const maskedAccount = `•••• ${request.accountNumber.slice(-4)}`;
  const label = request.status.charAt(0).toUpperCase() + request.status.slice(1);
  return (
    <div className={`flex items-center gap-3 rounded-2xl border border-[#e8f0ec] bg-white/70 ${compact ? "p-3" : "p-4 shadow-[0_14px_30px_rgba(31,90,73,0.05)]"}`}>
      <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl ${statusColor}`}>
        {request.status === "paid" ? <Check className="h-5 w-5" /> : <Clock3 className="h-5 w-5" />}
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-black">{method?.label ?? request.methodCode}</p>
        <p className="mt-1 text-xs text-[#778a82]">{maskedAccount}</p>
        {!compact && <p className="mt-1 text-[10px] text-[#9aa9a3]">{formatRequestDate(request.createdAt)}</p>}
      </div>
      <div className="text-right">
        <p className="text-sm font-black">{request.amountPkr} PKR</p>
        <span className={`mt-1 inline-flex rounded-full px-2 py-1 text-[10px] font-black ${statusColor}`}>
          {label}
        </span>
      </div>
    </div>
  );
}

function formatRequestDate(value: string) {
  return new Date(value).toLocaleDateString([], {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function PageHeading({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string;
  title: string;
  description: string;
}) {
  return (
    <div className="mb-8">
      <p className="mb-2 text-sm font-semibold text-[#149a7f]">{eyebrow}</p>
      <h1 className="text-4xl font-black tracking-[-0.06em] sm:text-5xl">{title}</h1>
      <p className="mt-3 text-sm text-[#70817b]">{description}</p>
    </div>
  );
}

function NavButton({
  active,
  icon,
  label,
  onClick,
}: {
  active: boolean;
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      aria-current={active ? "page" : undefined}
      className={`flex min-w-0 flex-1 flex-col items-center justify-center gap-1 rounded-xl px-1 py-2 text-[11px] font-bold transition sm:px-3 sm:text-xs ${active ? "bg-[#eff6ff] text-[#2563eb]" : "text-[#8a9690] hover:bg-[#f4f7f6] hover:text-[#64716c]"}`}
      onClick={onClick}
      type="button"
    >
      {icon}
      {label}
    </button>
  );
}