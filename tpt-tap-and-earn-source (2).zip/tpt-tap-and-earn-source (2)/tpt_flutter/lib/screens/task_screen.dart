import 'package:flutter/material.dart';

class TaskScreen extends StatefulWidget {
  const TaskScreen({super.key});

  @override
  State<TaskScreen> createState() => _TaskScreenState();
}

class _TaskScreenState extends State<TaskScreen> {
  final _tasks = <_TaskItem>[
    const _TaskItem(
      title: 'Complete your first tap',
      subtitle: 'Tap once to start earning points.',
      reward: 1,
      completed: true,
      icon: Icons.touch_app_outlined,
    ),
    const _TaskItem(
      title: 'Tap five times today',
      subtitle: 'Build a simple daily earning habit.',
      reward: 5,
      icon: Icons.bolt_outlined,
    ),
    const _TaskItem(
      title: 'Invite a friend',
      subtitle: 'Grow the TPT community together.',
      reward: 10,
      icon: Icons.person_add_alt_1_outlined,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final completed = _tasks.where((task) => task.completed).length;
    final primary = Theme.of(context).colorScheme.primary;

    return CustomScrollView(
      slivers: [
        const SliverAppBar(
          pinned: true,
          title: Text(
            'Task',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              Text(
                'Earn more points',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Complete tasks to unlock extra rewards.',
                style: TextStyle(color: Color(0xFF6B7A75)),
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: primary,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.flag_outlined, color: Colors.white, size: 28),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Text(
                        '$completed of ${_tasks.length} tasks complete',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    Text(
                      '${completed * 100 ~/ _tasks.length}%',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              ...List.generate(
                _tasks.length,
                (index) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Card(
                    child: CheckboxListTile(
                      value: _tasks[index].completed,
                      onChanged: (value) {
                        setState(() {
                          _tasks[index] = _tasks[index].copyWith(
                            completed: value ?? false,
                          );
                        });
                      },
                      controlAffinity: ListTileControlAffinity.leading,
                      activeColor: primary,
                      secondary: Icon(_tasks[index].icon, color: primary),
                      title: Text(
                        _tasks[index].title,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      subtitle: Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(
                          '${_tasks[index].subtitle}\n+${_tasks[index].reward} points',
                        ),
                      ),
                      isThreeLine: true,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 5,
                      ),
                    ),
                  ),
                ),
              ),
            ]),
          ),
        ),
      ],
    );
  }
}

class _TaskItem {
  const _TaskItem({
    required this.title,
    required this.subtitle,
    required this.reward,
    required this.icon,
    this.completed = false,
  });

  final String title;
  final String subtitle;
  final int reward;
  final IconData icon;
  final bool completed;

  _TaskItem copyWith({bool? completed}) {
    return _TaskItem(
      title: title,
      subtitle: subtitle,
      reward: reward,
      icon: icon,
      completed: completed ?? this.completed,
    );
  }
}