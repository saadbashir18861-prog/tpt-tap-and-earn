import 'package:flutter/material.dart';

import '../models/team_summary.dart';
import '../services/supabase_service.dart';

class TeamScreen extends StatefulWidget {
  const TeamScreen({super.key});

  @override
  State<TeamScreen> createState() => _TeamScreenState();
}

class _TeamScreenState extends State<TeamScreen> {
  final _service = SupabaseService();
  List<TeamSummary> _summary = [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final summary = await _service.getTeamSummary();
      if (!mounted) return;
      setState(() {
        _summary = summary;
        _isLoading = false;
        _error = null;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _error = 'Could not load your team summary.';
        });
      }
    }
  }

  List<Widget> _buildLevelCards(Color primary) {
    return _summary.map((level) {
      final icon = switch (level.level) {
        'A-Level' => Icons.workspace_premium_rounded,
        'B-Level' => Icons.groups_rounded,
        _ => Icons.people_alt_rounded,
      };

      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 25,
                  backgroundColor: primary.withValues(alpha: 0.12),
                  foregroundColor: primary,
                  child: Icon(icon),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        level.level,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        '${level.memberCount} members',
                        style: const TextStyle(
                          color: Color(0xFF6B7A75),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      '${level.earning} PKR',
                      style: TextStyle(
                        color: primary,
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const Text(
                      'earning',
                      style: TextStyle(
                        color: Color(0xFF8A9892),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      );
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    final totalMembers = _summary.fold<int>(0, (sum, item) => sum + item.memberCount);

    return CustomScrollView(
      slivers: [
        const SliverAppBar(
          pinned: true,
          title: Text(
            'Team',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              Text(
                'Your team',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Track your team levels, members, and referral earnings.',
                style: TextStyle(color: Color(0xFF6B7A75)),
              ),
              const SizedBox(height: 22),
              if (_error != null)
                Text(_error!, style: const TextStyle(color: Color(0xFFB64242))),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF123B36), Color(0xFF116E5E)],
                  ),
                  borderRadius: BorderRadius.circular(24),
                ),
                  child: Row(
                  children: [
                    Icon(Icons.groups_outlined, color: Color(0xFFB6F7E8), size: 30),
                    SizedBox(width: 14),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                            _isLoading ? 'Loading team' : '$totalMembers members',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        SizedBox(height: 3),
                        Text(
                          'Growing your network',
                          style: TextStyle(color: Color(0xFFA9D6CB)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              ...(_isLoading
                  ? const [
                      Padding(
                        padding: EdgeInsets.all(24),
                        child: Center(child: CircularProgressIndicator()),
                      ),
                    ]
                  : _buildLevelCards(primary)),
            ]),
          ),
        ),
      ],
    );
  }
}