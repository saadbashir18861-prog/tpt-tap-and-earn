# TPT — Tap & Earn

TPT is a Flutter app where signed-in users tap a button to earn points. Authentication is handled by Supabase Auth and points are stored in Supabase so they persist across devices and sessions.

## Supabase setup

1. Create or open a Supabase project.
2. In the Supabase SQL editor, run [`supabase/schema.sql`](supabase/schema.sql).
3. In Authentication → Providers, enable Email.
4. Keep email confirmation enabled for production. New accounts will see a message asking them to confirm their email.

## Run locally

From this directory:

```bash
flutter pub get
flutter run \
  --dart-define=SUPABASE_URL=https://your-project.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=your-public-anon-key
```

The project includes `.env.json` as a local, git-ignored configuration file. Replace its two placeholder values with the Supabase project URL and public anon key from your Supabase project, then use:

```bash
flutter run --dart-define-from-file=.env.json
```

`.env.json` is ignored by git. The app intentionally does not contain Supabase credentials in source code. Never use a Supabase `service_role` key in this file or in a mobile app.

When running inside Replit, the project secrets are already named
`SUPABASE_URL` and `SUPABASE_ANON_KEY`. Use the secure launcher so the
values are passed directly to Flutter without writing them to source:

```bash
./run_with_supabase.sh
```

The launcher fails explicitly if either secret is missing.

## Screens

- Login / create account with email and password
- Home with a large TAP button and cloud-saved total
- Profile with email, total points, wallet, and sign out
- Withdraw History with JazzCash/Easypaisa requests, 500 PKR minimum, and status tracking
- Admin-only withdrawal queue for `Pending → Approved → Paid` plus rejection
- Team dashboard with live A-Level, B-Level, and C-Level commission summaries

## Data safety

The profile table uses row-level security so a user can read only their own points. The app increments points through an atomic `increment_points()` RPC, preventing fast taps from overwriting each other.

Withdrawal requests are created through the `request_withdrawal()` RPC and are never inserted directly by the mobile client. Approval uses the protected `approve_withdrawal_request()` RPC, which checks the admin flag, locks the request and profile row, and deducts coins exactly once. `reject_withdrawal_request()` rejects a pending request without deducting coins. `mark_withdrawal_paid()` is a separate protected transition for recording the completed payout.

The schema also adds the requested application tables in an Auth-compatible form:

- `public.users` stores name, email, phone, referral code, referrer, balance, and VIP level. Its `id` is the matching `auth.users.id`; it is not a second login system.
- `public.commission_history` stores the earner, receiver, A/B/C level, commission type, amount, and timestamp.
- `get_team_summary()` returns the three level rows used by the Flutter Team tab.
- `public.withdraw_requests` retains the existing safe RPC lifecycle and adds compatibility `amount` and `method` fields for the requested SQL shape.

`profiles.points` remains the atomic coin source. A database trigger mirrors it to `users.balance`, so tapping and approved withdrawals stay consistent.

To make an account an admin after running the schema, execute this in Supabase SQL editor using a trusted admin session:

```sql
update public.profiles
set is_admin = true
where id = 'YOUR_AUTH_USER_UUID';
```

Withdrawal methods are stored in `withdraw_methods`. Phase 1 seeds JazzCash and Easypaisa. A future method such as UBL Bank can be enabled by inserting an active method row with a new `code` and `label`; the request table and RPC contract do not need to change.