import 'package:flutter/material.dart';

class NewsScreen extends StatelessWidget {
  const NewsScreen({super.key});

  static const _articles = [
    (
      category: 'TPT UPDATE',
      title: 'Every tap now counts toward your daily goal',
      summary: 'Keep your momentum going and check in each day to grow your points.',
      date: 'Today',
      icon: Icons.campaign_outlined,
    ),
    (
      category: 'COMMUNITY',
      title: 'Welcome to the TPT community',
      summary: 'Invite friends, complete tasks, and build your points together.',
      date: 'Yesterday',
      icon: Icons.forum_outlined,
    ),
    (
      category: 'TIP OF THE DAY',
      title: 'Small habits create bigger rewards',
      summary: 'A few consistent taps every day can turn into a strong weekly streak.',
      date: '2 days ago',
      icon: Icons.lightbulb_outline,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;

    return CustomScrollView(
      slivers: [
        const SliverAppBar(
          pinned: true,
          title: Text(
            'News',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              Text(
                'Latest from TPT',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.w900,
                    ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Updates, tips, and community news for your earning journey.',
                style: TextStyle(color: Color(0xFF6B7A75)),
              ),
              const SizedBox(height: 22),
              ..._articles.map(
                (article) => Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 46,
                            height: 46,
                            decoration: BoxDecoration(
                              color: primary.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: Icon(article.icon, color: primary),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  article.category,
                                  style: TextStyle(
                                    color: primary,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w800,
                                    letterSpacing: 1.2,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  article.title,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  article.summary,
                                  style: const TextStyle(
                                    color: Color(0xFF6B7A75),
                                    height: 1.4,
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  article.date,
                                  style: const TextStyle(
                                    color: Color(0xFF93A19C),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ]),
          ),
        ),
      ],
    );
  }
}