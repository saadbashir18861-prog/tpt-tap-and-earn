#!/usr/bin/env bash
set -euo pipefail

: "${SUPABASE_URL:?Missing SUPABASE_URL secret}"
: "${SUPABASE_ANON_KEY:?Missing SUPABASE_ANON_KEY secret}"

exec flutter run \
  --dart-define="SUPABASE_URL=${SUPABASE_URL}" \
  --dart-define="SUPABASE_ANON_KEY=${SUPABASE_ANON_KEY}" \
  "$@"