import 'package:flutter/material.dart';

import 'admin_withdrawals_screen.dart';
import 'withdraw_history_screen.dart';
import '../services/supabase_service.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _service = SupabaseService();
  int _points = 0;
  bool _isAdmin = false;
  bool _isLoading = true;
  bool _isSigningOut = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    try {
      final profile = await _service.getProfile();
      if (!mounted) return;
      setState(() {
        _points = profile?.points ?? 0;
        _isAdmin = profile?.isAdmin ?? false;
        _isLoading = false;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _error = 'Could not load your profile.';
        });
      }
    }
  }

  Future<void> _signOut() async {
    setState(() => _isSigningOut = true);
    try {
      await _service.signOut();
    } catch (_) {
      if (mounted) {
        setState(() {
          _isSigningOut = false;
          _error = 'Could not sign out. Please try again.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = _service.currentUser;
    final email = user?.email ?? 'Unknown email';
    final initial = email.isEmpty ? 'T' : email.substring(0, 1).toUpperCase();

    return CustomScrollView(
      slivers: [
        SliverAppBar(
          pinned: true,
          title: const Text(
            'Profile',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          actions: [
            IconButton(
              tooltip: 'Sign out',
              onPressed: _isSigningOut ? null : _signOut,
              icon: _isSigningOut
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.logout_rounded),
            ),
            const SizedBox(width: 10),
          ],
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
          sliver: SliverList(
            delegate: SliverChildListDelegate([
              Center(
                child: CircleAvatar(
                  radius: 42,
                  backgroundColor: Theme.of(context).colorScheme.primary,
                  child: Text(
                    initial,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 30,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                email,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
              ),
              const SizedBox(height: 28),
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: const Color(0xFFE0E9E5)),
                ),
                child: Column(
                  children: [
                    const Text(
                      'TOTAL EARNING',
                      style: TextStyle(
                        color: Color(0xFF6B7A75),
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    _isLoading
                        ? const SizedBox(
                            width: 27,
                            height: 27,
                            child: CircularProgressIndicator(strokeWidth: 2.5),
                          )
                        : Text(
                            '$_points',
                            style: Theme.of(context).textTheme.displaySmall?.copyWith(
                                  color: Theme.of(context).colorScheme.primary,
                                  fontWeight: FontWeight.w900,
                                ),
                          ),
                    const SizedBox(height: 4),
                    const Text(
                      'Keep tapping to grow your total.',
                      style: TextStyle(color: Color(0xFF6B7A75)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: const Color(0xFFE0E9E5)),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF3D6),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: const Icon(
                        Icons.account_balance_wallet_outlined,
                        color: Color(0xFFB47B14),
                      ),
                    ),
                    const SizedBox(width: 14),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Wallet',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                       'Your available TPT coin balance',
                            style: TextStyle(
                              color: Color(0xFF6B7A75),
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      '$_points',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.primary,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              OutlinedButton.icon(
                onPressed: () async {
                  await Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const WithdrawHistoryScreen(),
                    ),
                  );
                  if (mounted) _loadProfile();
                },
                icon: const Icon(Icons.account_balance_wallet_rounded),
                label: const Text('Withdraw funds'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Theme.of(context).colorScheme.primary,
                  minimumSize: const Size.fromHeight(52),
                  side: BorderSide(color: Theme.of(context).colorScheme.primary),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
              if (_isAdmin) ...[
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const AdminWithdrawalsScreen(),
                      ),
                    );
                  },
                  icon: const Icon(Icons.admin_panel_settings_rounded),
                  label: const Text('Manage withdrawal requests'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF3E6FC0),
                    minimumSize: const Size.fromHeight(52),
                    side: const BorderSide(color: Color(0xFFB9CBEA)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                ),
              ],
              if (_error != null) ...[
                const SizedBox(height: 18),
                Text(
                  _error!,
                  style: const TextStyle(color: Color(0xFFB64242)),
                  textAlign: TextAlign.center,
                ),
              ],
              const SizedBox(height: 30),
              OutlinedButton.icon(
                onPressed: _isSigningOut ? null : _signOut,
                icon: const Icon(Icons.logout_rounded),
                label: const Text('Sign out'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFFB64242),
                  minimumSize: const Size.fromHeight(52),
                  side: const BorderSide(color: Color(0xFFE7CACA)),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
            ]),
          ),
        ),
      ],
    );
  }
}