class WithdrawMethod {
  const WithdrawMethod({
    required this.code,
    required this.label,
  });

  final String code;
  final String label;

  factory WithdrawMethod.fromMap(Map<String, dynamic> map) {
    return WithdrawMethod(
      code: map['code'] as String,
      label: map['label'] as String,
    );
  }
}

class WithdrawRequest {
  const WithdrawRequest({
    required this.id,
    required this.methodCode,
    required this.accountNumber,
    required this.amountPkr,
    required this.status,
    required this.createdAt,
    this.approvedAt,
    this.paidAt,
  });

  final String id;
  final String methodCode;
  final String accountNumber;
  final int amountPkr;
  final String status;
  final DateTime createdAt;
  final DateTime? approvedAt;
  final DateTime? paidAt;

  factory WithdrawRequest.fromMap(Map<String, dynamic> map) {
    final rawAmount = map['amount_pkr'] ?? map['amount'];
    final rawMethod = map['method_code'] ?? map['method'];
    final rawStatus = map['status'] as String? ?? 'pending';
    return WithdrawRequest(
      id: map['id'] as String,
      methodCode: (rawMethod as String).toLowerCase(),
      accountNumber: map['account_number'] as String,
      amountPkr: (rawAmount as num).toInt(),
      status: rawStatus.toLowerCase(),
      createdAt: DateTime.parse(map['created_at'] as String),
      approvedAt: _parseDate(map['approved_at']),
      paidAt: _parseDate(map['paid_at']),
    );
  }

  static DateTime? _parseDate(Object? value) {
    if (value is! String || value.isEmpty) return null;
    return DateTime.tryParse(value);
  }
}