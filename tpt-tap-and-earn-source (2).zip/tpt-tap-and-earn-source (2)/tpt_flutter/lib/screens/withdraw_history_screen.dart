import 'package:flutter/material.dart';

import '../models/withdraw_request.dart';
import '../services/supabase_service.dart';

class WithdrawHistoryScreen extends StatefulWidget {
  const WithdrawHistoryScreen({super.key});

  @override
  State<WithdrawHistoryScreen> createState() => _WithdrawHistoryScreenState();
}

class _WithdrawHistoryScreenState extends State<WithdrawHistoryScreen> {
  final _service = SupabaseService();
  final _accountController = TextEditingController();
  final _amountController = TextEditingController();
  List<WithdrawMethod> _methods = [];
  List<WithdrawRequest> _requests = [];
  String? _selectedMethod;
  String? _error;
  String? _notice;
  int _points = 0;
  bool _isLoading = true;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _accountController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final results = await Future.wait([
        _service.getWithdrawMethods(),
        _service.getWithdrawHistory(),
        _service.getProfile(),
      ]);
      if (!mounted) return;
      final methods = results[0] as List<WithdrawMethod>;
      final requests = results[1] as List<WithdrawRequest>;
      final profile = results[2] as dynamic;
      setState(() {
        _methods = methods;
        _requests = requests;
        _points = profile?.points ?? 0;
        _selectedMethod ??= methods.isEmpty ? null : methods.first.code;
        _isLoading = false;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _error = 'Could not load withdrawal details. Pull to try again.';
        });
      }
    }
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    setState(() {
      _error = null;
      _notice = null;
    });
    final account = _accountController.text.trim();
    final amount = int.tryParse(_amountController.text.trim());
    if (_selectedMethod == null) {
      setState(() => _error = 'Choose a withdrawal method.');
      return;
    }
    if (!RegExp(r'^[0-9]{8,20}$').hasMatch(account)) {
      setState(() => _error = 'Enter a valid account number using 8 to 20 digits.');
      return;
    }
    if (amount == null || amount < 500) {
      setState(() => _error = 'Minimum withdrawal is 500 PKR.');
      return;
    }
    if (amount > _points) {
      setState(() => _error = 'You do not have enough coins for this withdrawal.');
      return;
    }

    setState(() => _isSubmitting = true);
    try {
      await _service.requestWithdrawal(
        methodCode: _selectedMethod!,
        accountNumber: account,
        amountPkr: amount,
      );
      if (!mounted) return;
      _accountController.clear();
      _amountController.clear();
      setState(() {
        _isSubmitting = false;
        _notice = 'Withdrawal request submitted for admin review.';
      });
      await _load();
    } catch (_) {
      if (mounted) {
        setState(() {
          _isSubmitting = false;
          _error = 'Could not submit the request. Please check your balance and try again.';
        });
      }
    }
  }

  String _methodLabel(String code) {
    for (final method in _methods) {
      if (method.code == code) return method.label;
    }
    return code == 'jazzcash' ? 'JazzCash' : 'Easypaisa';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Withdraw History',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
          children: [
            _WithdrawForm(
              methods: _methods,
              selectedMethod: _selectedMethod,
              onMethodChanged: (value) => setState(() => _selectedMethod = value),
              accountController: _accountController,
              amountController: _amountController,
              points: _points,
              isLoading: _isLoading,
              isSubmitting: _isSubmitting,
              onSubmit: _submit,
            ),
            if (_error != null) ...[
              const SizedBox(height: 14),
              _Message(text: _error!, isError: true),
            ],
            if (_notice != null) ...[
              const SizedBox(height: 14),
              _Message(text: _notice!, isError: false),
            ],
            const SizedBox(height: 28),
            const Text(
              'Recent requests',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 12),
            if (_isLoading)
              const Padding(
                padding: EdgeInsets.all(28),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (_requests.isEmpty)
              const _EmptyHistory()
            else
              ..._requests.map(
                (request) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: _RequestCard(
                    request: request,
                    methodLabel: _methodLabel(request.methodCode),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _WithdrawForm extends StatelessWidget {
  const _WithdrawForm({
    required this.methods,
    required this.selectedMethod,
    required this.onMethodChanged,
    required this.accountController,
    required this.amountController,
    required this.points,
    required this.isLoading,
    required this.isSubmitting,
    required this.onSubmit,
  });

  final List<WithdrawMethod> methods;
  final String? selectedMethod;
  final ValueChanged<String?> onMethodChanged;
  final TextEditingController accountController;
  final TextEditingController amountController;
  final int points;
  final bool isLoading;
  final bool isSubmitting;
  final VoidCallback onSubmit;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Withdraw coins',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 6),
            const Text(
              'Choose a wallet and request your coins in PKR. Admin approval is required before payment.',
              style: TextStyle(color: Color(0xFF6B7A75), height: 1.4),
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF8E7),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  const Icon(Icons.account_balance_wallet_rounded, color: Color(0xFFB47B14)),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Text(
                      'Available coins',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                  Text(
                    '$points',
                    style: const TextStyle(
                      color: Color(0xFF9A6A10),
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            DropdownButtonFormField<String>(
              value: selectedMethod,
              decoration: const InputDecoration(
                labelText: 'Withdrawal method',
                prefixIcon: Icon(Icons.phone_android_rounded),
              ),
              items: methods
                  .map(
                    (method) => DropdownMenuItem(
                      value: method.code,
                      child: Text(method.label),
                    ),
                  )
                  .toList(),
              onChanged: isLoading ? null : onMethodChanged,
            ),
            const SizedBox(height: 14),
            TextField(
              controller: accountController,
              keyboardType: TextInputType.phone,
              maxLength: 20,
              decoration: const InputDecoration(
                labelText: 'Account number',
                hintText: 'e.g. 03001234567',
                prefixIcon: Icon(Icons.call_rounded),
                counterText: '',
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Amount (PKR)',
                hintText: 'Minimum 500',
                prefixIcon: Icon(Icons.payments_rounded),
              ),
            ),
            const SizedBox(height: 18),
            ElevatedButton.icon(
              onPressed: isSubmitting || isLoading || methods.isEmpty ? null : onSubmit,
              icon: isSubmitting
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.arrow_forward_rounded),
              label: Text(isSubmitting ? 'Submitting...' : 'Request withdrawal'),
            ),
          ],
        ),
      ),
    );
  }
}

class _RequestCard extends StatelessWidget {
  const _RequestCard({
    required this.request,
    required this.methodLabel,
  });

  final WithdrawRequest request;
  final String methodLabel;

  @override
  Widget build(BuildContext context) {
    final status = request.status;
    final isPaid = status == 'paid';
    final isApproved = status == 'approved';
    final isRejected = status == 'rejected';
    final color = isPaid
        ? const Color(0xFF168C70)
        : isApproved
            ? const Color(0xFF3E6FC0)
            : isRejected
                ? const Color(0xFFB64242)
                : const Color(0xFFB47B14);
    final icon = isPaid
        ? Icons.check_circle_rounded
        : isApproved
            ? Icons.verified_rounded
            : isRejected
                ? Icons.cancel_rounded
                : Icons.schedule_rounded;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            CircleAvatar(
              radius: 24,
              backgroundColor: color.withValues(alpha: 0.12),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(methodLabel, style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(
                    '•••• ${request.accountNumber.substring(request.accountNumber.length - 4)}',
                    style: const TextStyle(color: Color(0xFF6B7A75), fontSize: 12),
                  ),
                  const SizedBox(height: 7),
                  Text(
                    _formatDate(request.createdAt),
                    style: const TextStyle(color: Color(0xFF9AA7A2), fontSize: 11),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  '${request.amountPkr} PKR',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 6),
                DecoratedBox(
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                    child: Text(
                      status[0].toUpperCase() + status.substring(1),
                      style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    final local = date.toLocal();
    return '${local.day.toString().padLeft(2, '0')}/${local.month.toString().padLeft(2, '0')}/${local.year}';
  }
}

class _EmptyHistory extends StatelessWidget {
  const _EmptyHistory();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFE0E9E5)),
      ),
      child: const Column(
        children: [
          Icon(Icons.receipt_long_rounded, size: 36, color: Color(0xFF9AA7A2)),
          SizedBox(height: 10),
          Text('No withdrawal requests yet', style: TextStyle(fontWeight: FontWeight.w800)),
          SizedBox(height: 4),
          Text(
            'Your requests will appear here with their status.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Color(0xFF6B7A75), fontSize: 12),
          ),
        ],
      ),
    );
  }
}

class _Message extends StatelessWidget {
  const _Message({required this.text, required this.isError});

  final String text;
  final bool isError;

  @override
  Widget build(BuildContext context) {
    final color = isError ? const Color(0xFFB64242) : const Color(0xFF147B68);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Text(text, style: TextStyle(color: color, fontWeight: FontWeight.w600)),
    );
  }
}