-- Run this once in the Supabase SQL editor.
-- This is intentionally compatible with Supabase Auth:
-- public.users mirrors auth.users, while profiles.points remains the
-- existing atomic coin source used by the app.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  points bigint not null default 0 check (points >= 0),
  is_admin boolean not null default false,
  name text,
  email text,
  phone text,
  referral_code text,
  referred_by text,
  vip_level integer not null default 1 check (vip_level >= 1),
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

alter table public.profiles
  add column if not exists is_admin boolean not null default false,
  add column if not exists name text,
  add column if not exists email text,
  add column if not exists phone text,
  add column if not exists referral_code text,
  add column if not exists referred_by text,
  add column if not exists vip_level integer not null default 1;

create unique index if not exists profiles_referral_code_key
  on public.profiles (referral_code)
  where referral_code is not null;

alter table public.profiles enable row level security;

-- Auth-compatible user profile table based on the requested users shape.
-- The id is the Supabase auth user id instead of a second unrelated UUID.
create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  name text,
  email text unique,
  phone text,
  referral_code text unique,
  referred_by text,
  balance numeric not null default 0 check (balance >= 0),
  vip_level integer not null default 1 check (vip_level >= 1),
  created_at timestamptz not null default timezone('utc', now())
);

alter table public.users
  add column if not exists name text,
  add column if not exists email text,
  add column if not exists phone text,
  add column if not exists referral_code text,
  add column if not exists referred_by text,
  add column if not exists balance numeric not null default 0,
  add column if not exists vip_level integer not null default 1;

alter table public.users enable row level security;

drop policy if exists "Users can view their own user profile" on public.users;
create policy "Users can view their own user profile"
  on public.users for select
  to authenticated
  using (
    auth.uid() = id
    or exists (
      select 1 from public.profiles
      where profiles.id = auth.uid()
        and profiles.is_admin = true
    )
  );

revoke insert, update, delete on public.users from authenticated;
grant select on public.users to authenticated;

drop policy if exists "Users can view their own profile" on public.profiles;
create policy "Users can view their own profile"
  on public.profiles for select
  to authenticated
  using (auth.uid() = id);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = timezone('utc', now());
  return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at
  before update on public.profiles
  for each row execute procedure public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.users (
    id,
    name,
    email,
    phone,
    referral_code,
    referred_by
  )
  values (
    new.id,
    new.raw_user_meta_data ->> 'name',
    new.email,
    new.raw_user_meta_data ->> 'phone',
    coalesce(
      new.raw_user_meta_data ->> 'referral_code',
      upper(substr(replace(new.id::text, '-', ''), 1, 8))
    ),
    new.raw_user_meta_data ->> 'referred_by'
  )
  on conflict (id) do update
  set email = excluded.email;
  insert into public.profiles (id, name, email, phone, referral_code, referred_by)
  values (
    new.id,
    new.raw_user_meta_data ->> 'name',
    new.email,
    new.raw_user_meta_data ->> 'phone',
    coalesce(
      new.raw_user_meta_data ->> 'referral_code',
      upper(substr(replace(new.id::text, '-', ''), 1, 8))
    ),
    new.raw_user_meta_data ->> 'referred_by'
  )
  on conflict (id) do update
  set email = excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Backfill users if this script is being added to an existing project.
insert into public.profiles (id)
select id from auth.users
on conflict (id) do nothing;

-- Backfill the compatibility user rows without overwriting existing balances.
insert into public.users (
  id,
  name,
  email,
  phone,
  referral_code,
  referred_by,
  balance,
  vip_level
)
select
  au.id,
  au.raw_user_meta_data ->> 'name',
  au.email,
  au.raw_user_meta_data ->> 'phone',
  coalesce(
    au.raw_user_meta_data ->> 'referral_code',
    upper(substr(replace(au.id::text, '-', ''), 1, 8))
  ),
  au.raw_user_meta_data ->> 'referred_by',
  coalesce(p.points, 0),
  coalesce(p.vip_level, 1)
from auth.users au
left join public.profiles p on p.id = au.id
on conflict (id) do nothing;

create or replace function public.sync_user_balance()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.users (id, email, balance)
  values (new.id, new.email, new.points)
  on conflict (id) do update
  set balance = excluded.balance,
      email = coalesce(excluded.email, public.users.email);
  return new;
end;
$$;

drop trigger if exists profiles_sync_user_balance on public.profiles;
create trigger profiles_sync_user_balance
  after insert or update of points on public.profiles
  for each row execute procedure public.sync_user_balance();

create or replace function public.increment_points()
returns bigint
language sql
security definer
set search_path = public
as $$
  update public.profiles
  set points = points + 1
  where id = auth.uid()
  returning points;
$$;

revoke execute on function public.increment_points() from public;
grant execute on function public.increment_points() to authenticated;

-- Commission ledger requested for A/B/C team earnings.
create table if not exists public.commission_history (
  id uuid primary key default gen_random_uuid(),
  earner_id uuid not null references public.users(id) on delete cascade,
  receiver_id uuid not null references public.users(id) on delete cascade,
  level text not null check (level in ('A-Level', 'B-Level', 'C-Level')),
  type text not null check (type in ('Joining', 'Task')),
  amount numeric not null check (amount >= 0),
  created_at timestamptz not null default timezone('utc', now())
);

alter table public.commission_history enable row level security;

drop policy if exists "Users can view their received commissions"
  on public.commission_history;
create policy "Users can view their received commissions"
  on public.commission_history for select
  to authenticated
  using (receiver_id = auth.uid());

revoke insert, update, delete on public.commission_history from authenticated;
grant select on public.commission_history to authenticated;

create index if not exists commission_history_receiver_level_idx
  on public.commission_history (receiver_id, level, created_at desc);

create or replace function public.get_team_summary()
returns table (
  level text,
  member_count bigint,
  earning numeric
)
language sql
security definer
set search_path = public
as $$
  with levels(level, sort_order) as (
    values
      ('A-Level', 1),
      ('B-Level', 2),
      ('C-Level', 3)
  )
  select
    levels.level,
    count(distinct commissions.earner_id)::bigint as member_count,
    coalesce(sum(commissions.amount), 0)::numeric as earning
  from levels
  left join public.commission_history commissions
    on commissions.level = levels.level
   and commissions.receiver_id = auth.uid()
  group by levels.level, levels.sort_order
  order by levels.sort_order;
$$;

revoke execute on function public.get_team_summary() from public;
grant execute on function public.get_team_summary() to authenticated;

-- Withdrawal methods are data-driven so a future method such as UBL Bank
-- can be enabled with one insert instead of changing the request table.
create table if not exists public.withdraw_methods (
  code text primary key,
  label text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default timezone('utc', now())
);

alter table public.withdraw_methods enable row level security;

drop policy if exists "Authenticated users can view active withdrawal methods"
  on public.withdraw_methods;
create policy "Authenticated users can view active withdrawal methods"
  on public.withdraw_methods for select
  to authenticated
  using (is_active = true);

insert into public.withdraw_methods (code, label)
values
  ('jazzcash', 'JazzCash'),
  ('easypaisa', 'Easypaisa')
on conflict (code) do update
set label = excluded.label;

create table if not exists public.withdraw_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  method_code text not null references public.withdraw_methods(code),
  account_number text not null,
  amount_pkr bigint not null check (amount_pkr >= 500),
  status text not null default 'pending'
    check (status in ('pending', 'approved', 'paid')),
  created_at timestamptz not null default timezone('utc', now()),
  approved_at timestamptz,
  approved_by uuid references auth.users(id),
  paid_at timestamptz,
  paid_by uuid references auth.users(id)
);

-- Compatibility aliases for the requested SQL shape. The app keeps the
-- lower-case canonical fields/statuses for existing RPC compatibility.
alter table public.withdraw_requests
  add column if not exists method_code text,
  add column if not exists account_number text,
  add column if not exists amount_pkr bigint,
  add column if not exists approved_at timestamptz,
  add column if not exists approved_by uuid,
  add column if not exists paid_at timestamptz,
  add column if not exists paid_by uuid,
  add column if not exists amount numeric,
  add column if not exists method text;

alter table public.withdraw_requests
  drop constraint if exists withdraw_requests_status_check;

-- Convert rows from the requested shape before adding the canonical checks.
update public.withdraw_requests
set amount_pkr = coalesce(amount_pkr, round(amount)::bigint),
    method_code = coalesce(method_code, lower(trim(method))),
    status = lower(trim(status))
where amount_pkr is null
   or method_code is null
   or status <> lower(trim(status));

alter table public.withdraw_requests
  alter column method_code set not null,
  alter column account_number set not null,
  alter column amount_pkr set not null;

alter table public.withdraw_requests
  add constraint withdraw_requests_status_check
  check (status in ('pending', 'approved', 'paid', 'rejected'));

do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conname = 'withdraw_requests_amount_pkr_check'
      and conrelid = 'public.withdraw_requests'::regclass
  ) then
    alter table public.withdraw_requests
      add constraint withdraw_requests_amount_pkr_check
      check (amount_pkr >= 500);
  end if;
end;
$$;

create or replace function public.sync_withdraw_compat_fields()
returns trigger
language plpgsql
as $$
begin
  if new.amount_pkr is null and new.amount is not null then
    new.amount_pkr := round(new.amount)::bigint;
  end if;
  if new.amount is null and new.amount_pkr is not null then
    new.amount := new.amount_pkr;
  end if;
  if new.method_code is null and new.method is not null then
    new.method_code := lower(trim(new.method));
  end if;
  if new.method is null and new.method_code is not null then
    new.method := case lower(trim(new.method_code))
      when 'jazzcash' then 'JazzCash'
      when 'easypaisa' then 'Easypaisa'
      else new.method_code
    end;
  end if;
  new.status := lower(trim(new.status));
  return new;
end;
$$;

do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conname = 'withdraw_requests_method_code_fkey'
      and conrelid = 'public.withdraw_requests'::regclass
  ) then
    alter table public.withdraw_requests
      add constraint withdraw_requests_method_code_fkey
      foreign key (method_code) references public.withdraw_methods(code);
  end if;
end;
$$;

drop trigger if exists withdraw_requests_sync_compat on public.withdraw_requests;
create trigger withdraw_requests_sync_compat
  before insert or update on public.withdraw_requests
  for each row execute procedure public.sync_withdraw_compat_fields();

update public.withdraw_requests
set amount = amount_pkr,
    method = case method_code
      when 'jazzcash' then 'JazzCash'
      when 'easypaisa' then 'Easypaisa'
      else method_code
    end
where amount is null or method is null;

alter table public.withdraw_requests enable row level security;

drop policy if exists "Users can view their own withdrawal requests"
  on public.withdraw_requests;
create policy "Users can view their own withdrawal requests"
  on public.withdraw_requests for select
  to authenticated
  using (
    auth.uid() = user_id
    or exists (
      select 1
      from public.profiles
      where profiles.id = auth.uid()
        and profiles.is_admin = true
    )
  );

revoke insert, update, delete on public.withdraw_requests from authenticated;
revoke insert, update, delete on public.withdraw_methods from authenticated;
grant select on public.withdraw_methods to authenticated;
grant select on public.withdraw_requests to authenticated;

create or replace function public.request_withdrawal(
  p_method_code text,
  p_account_number text,
  p_amount_pkr bigint
)
returns public.withdraw_requests
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_points bigint;
  v_pending bigint;
  v_request public.withdraw_requests;
begin
  if v_user_id is null then
    raise exception 'You must be signed in to request a withdrawal.';
  end if;

  if p_amount_pkr < 500 then
    raise exception 'The minimum withdrawal is 500 PKR.';
  end if;

  if p_account_number !~ '^[0-9]{8,20}$' then
    raise exception 'Enter a valid account number using 8 to 20 digits.';
  end if;

  if not exists (
    select 1
    from public.withdraw_methods
    where code = lower(trim(p_method_code))
      and is_active = true
  ) then
    raise exception 'This withdrawal method is not available.';
  end if;

  select points
  into v_points
  from public.profiles
  where id = v_user_id
  for update;

  if v_points is null then
    raise exception 'Your profile could not be found.';
  end if;

  select coalesce(sum(amount_pkr), 0)
  into v_pending
  from public.withdraw_requests
  where user_id = v_user_id
    and status = 'pending';

  if v_points - v_pending < p_amount_pkr then
    raise exception 'You do not have enough available coins for this withdrawal.';
  end if;

  insert into public.withdraw_requests (
    user_id,
    method_code,
    account_number,
    amount_pkr
  )
  values (
    v_user_id,
    lower(trim(p_method_code)),
    trim(p_account_number),
    p_amount_pkr
  )
  returning * into v_request;

  return v_request;
end;
$$;

create or replace function public.approve_withdrawal_request(
  p_request_id uuid
)
returns public.withdraw_requests
language plpgsql
security definer
set search_path = public
as $$
declare
  v_admin_id uuid := auth.uid();
  v_request public.withdraw_requests;
  v_points bigint;
begin
  if not exists (
    select 1 from public.profiles
    where id = v_admin_id and is_admin = true
  ) then
    raise exception 'Only an admin can approve withdrawals.';
  end if;

  select *
  into v_request
  from public.withdraw_requests
  where id = p_request_id
  for update;

  if v_request.id is null then
    raise exception 'Withdrawal request not found.';
  end if;

  if v_request.status <> 'pending' then
    raise exception 'Only pending requests can be approved.';
  end if;

  select points
  into v_points
  from public.profiles
  where id = v_request.user_id
  for update;

  if v_points < v_request.amount_pkr then
    raise exception 'The user does not have enough coins to approve this withdrawal.';
  end if;

  update public.profiles
  set points = points - v_request.amount_pkr
  where id = v_request.user_id;

  update public.withdraw_requests
  set status = 'approved',
      approved_at = timezone('utc', now()),
      approved_by = v_admin_id
  where id = p_request_id
  returning * into v_request;

  return v_request;
end;
$$;

create or replace function public.mark_withdrawal_paid(
  p_request_id uuid
)
returns public.withdraw_requests
language plpgsql
security definer
set search_path = public
as $$
declare
  v_admin_id uuid := auth.uid();
  v_request public.withdraw_requests;
begin
  if not exists (
    select 1 from public.profiles
    where id = v_admin_id and is_admin = true
  ) then
    raise exception 'Only an admin can mark withdrawals as paid.';
  end if;

  select *
  into v_request
  from public.withdraw_requests
  where id = p_request_id
  for update;

  if v_request.id is null then
    raise exception 'Withdrawal request not found.';
  end if;

  if v_request.status <> 'approved' then
    raise exception 'Only approved requests can be marked as paid.';
  end if;

  update public.withdraw_requests
  set status = 'paid',
      paid_at = timezone('utc', now()),
      paid_by = v_admin_id
  where id = p_request_id
  returning * into v_request;

  return v_request;
end;
$$;

revoke execute on function public.request_withdrawal(text, text, bigint) from public;
revoke execute on function public.approve_withdrawal_request(uuid) from public;
revoke execute on function public.mark_withdrawal_paid(uuid) from public;
grant execute on function public.request_withdrawal(text, text, bigint) to authenticated;
grant execute on function public.approve_withdrawal_request(uuid) to authenticated;
grant execute on function public.mark_withdrawal_paid(uuid) to authenticated;

create or replace function public.reject_withdrawal_request(
  p_request_id uuid
)
returns public.withdraw_requests
language plpgsql
security definer
set search_path = public
as $$
declare
  v_admin_id uuid := auth.uid();
  v_request public.withdraw_requests;
begin
  if not exists (
    select 1 from public.profiles
    where id = v_admin_id and is_admin = true
  ) then
    raise exception 'Only an admin can reject withdrawals.';
  end if;

  select *
  into v_request
  from public.withdraw_requests
  where id = p_request_id
  for update;

  if v_request.id is null then
    raise exception 'Withdrawal request not found.';
  end if;

  if v_request.status <> 'pending' then
    raise exception 'Only pending requests can be rejected.';
  end if;

  update public.withdraw_requests
  set status = 'rejected'
  where id = p_request_id
  returning * into v_request;

  return v_request;
end;
$$;

revoke execute on function public.reject_withdrawal_request(uuid) from public;
grant execute on function public.reject_withdrawal_request(uuid) to authenticated;