import 'package:flutter/material.dart';

import '../models/withdraw_request.dart';
import '../services/supabase_service.dart';

class AdminWithdrawalsScreen extends StatefulWidget {
  const AdminWithdrawalsScreen({super.key});

  @override
  State<AdminWithdrawalsScreen> createState() => _AdminWithdrawalsScreenState();
}

class _AdminWithdrawalsScreenState extends State<AdminWithdrawalsScreen> {
  final _service = SupabaseService();
  List<WithdrawRequest> _requests = [];
  bool _isLoading = true;
  String? _error;
  String? _busyRequestId;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final requests = await _service.getAllWithdrawRequests();
      if (!mounted) return;
      setState(() {
        _requests = requests;
        _isLoading = false;
        _error = null;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _error = 'Could not load withdrawal requests.';
        });
      }
    }
  }

  Future<void> _advance(WithdrawRequest request) async {
    setState(() {
      _busyRequestId = request.id;
      _error = null;
    });
    try {
      final updated = request.status == 'pending'
          ? await _service.approveWithdrawalRequest(request.id)
          : await _service.markWithdrawalPaid(request.id);
      _replaceRequest(updated);
    } catch (_) {
      if (mounted) {
        setState(() {
          _busyRequestId = null;
          _error = 'Could not update this request. It may have changed already.';
        });
      }
    }
  }

  Future<void> _reject(WithdrawRequest request) async {
    setState(() {
      _busyRequestId = request.id;
      _error = null;
    });
    try {
      final updated = await _service.rejectWithdrawalRequest(request.id);
      _replaceRequest(updated);
    } catch (_) {
      if (mounted) {
        setState(() {
          _busyRequestId = null;
          _error = 'Could not reject this request. It may have changed already.';
        });
      }
    }
  }

  void _replaceRequest(WithdrawRequest updated) {
    if (!mounted) return;
    setState(() {
      _requests = _requests
          .map((item) => item.id == updated.id ? updated : item)
          .toList();
      _busyRequestId = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Withdrawal Requests',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
          children: [
            const Text(
              'Admin queue',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 6),
            const Text(
              'Approve a pending request to deduct coins atomically. Mark it paid only after the transfer is complete.',
              style: TextStyle(color: Color(0xFF6B7A75), height: 1.4),
            ),
            if (_error != null) ...[
              const SizedBox(height: 14),
              Text(
                _error!,
                style: const TextStyle(color: Color(0xFFB64242)),
              ),
            ],
            const SizedBox(height: 20),
            if (_isLoading)
              const Padding(
                padding: EdgeInsets.all(28),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (_requests.isEmpty)
              const Padding(
                padding: EdgeInsets.all(28),
                child: Center(child: Text('No withdrawal requests yet.')),
              )
            else
              ..._requests.map(
                (request) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: _AdminRequestCard(
                    request: request,
                    isBusy: _busyRequestId == request.id,
                    onAdvance: () => _advance(request),
                    onReject: () => _reject(request),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _AdminRequestCard extends StatelessWidget {
  const _AdminRequestCard({
    required this.request,
    required this.isBusy,
    required this.onAdvance,
    required this.onReject,
  });

  final WithdrawRequest request;
  final bool isBusy;
  final VoidCallback onAdvance;
  final VoidCallback onReject;

  @override
  Widget build(BuildContext context) {
    final isPending = request.status == 'pending';
    final isApproved = request.status == 'approved';
    final isPaid = request.status == 'paid';
    final isRejected = request.status == 'rejected';
    final method = request.methodCode == 'jazzcash' ? 'JazzCash' : 'Easypaisa';
    final statusColor = isPaid
        ? const Color(0xFF168C70)
        : isPending
            ? const Color(0xFFB47B14)
            : isRejected
                ? const Color(0xFFB64242)
            : const Color(0xFF3E6FC0);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    method,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
                  ),
                ),
                Text(
                  '${request.amountPkr} PKR',
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Account: ${request.accountNumber}',
              style: const TextStyle(color: Color(0xFF6B7A75)),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Text(
                  request.status[0].toUpperCase() + request.status.substring(1),
                  style: TextStyle(color: statusColor, fontWeight: FontWeight.w800),
                ),
                const Spacer(),
                if (isPending) ...[
                  OutlinedButton(
                    onPressed: isBusy ? null : onReject,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFFB64242),
                    ),
                    child: const Text('Reject'),
                  ),
                  const SizedBox(width: 8),
                ],
                if (isPending || isApproved)
                  OutlinedButton(
                    onPressed: isBusy ? null : onAdvance,
                    child: isBusy
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : Text(isPending ? 'Approve' : 'Mark paid'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}