# TPT — Tap & Earn

A Flutter app where users sign in with Supabase and earn cloud-saved points by tapping a button.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Flutter app: `cd tpt_flutter && flutter pub get && flutter run --dart-define-from-file=.env.json`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)
- Mobile: Flutter + Supabase Auth + Supabase Postgres

## Where things live

- `tpt_flutter/` — Flutter mobile app
- `tpt_flutter/lib/` — app screens, Supabase service, and models
- `tpt_flutter/supabase/schema.sql` — Supabase table, RLS policy, trigger, and atomic points RPC

## Architecture decisions

- Supabase Auth owns email/password sessions; no local authentication or password storage is used.
- The mobile client receives Supabase configuration through Dart defines instead of committing project credentials.
- Taps use an atomic Supabase RPC so concurrent taps cannot overwrite one another.
- Row-level security limits profile reads to the signed-in user's own row.

## Product

- Sign up and log in with email/password
- Tap to earn one point per successful cloud-saved tap
- View total points and account email
- Sign out and restore the session on relaunch

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Run `tpt_flutter/supabase/schema.sql` in the Supabase SQL editor before launching the app.
- Supply `SUPABASE_URL` and `SUPABASE_ANON_KEY` at Flutter run/build time.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
