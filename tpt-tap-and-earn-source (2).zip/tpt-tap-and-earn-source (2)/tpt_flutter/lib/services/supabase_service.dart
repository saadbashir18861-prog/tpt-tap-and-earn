import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/profile.dart';
import '../models/team_summary.dart';
import '../models/withdraw_request.dart';

class SupabaseService {
  SupabaseService({SupabaseClient? client})
      : _client = client ?? Supabase.instance.client;

  final SupabaseClient _client;

  User? get currentUser => _client.auth.currentUser;

  Future<Profile?> getProfile() async {
    final user = currentUser;
    if (user == null) return null;

    final row = await _client.from('profiles').select().eq('id', user.id).maybeSingle();
    if (row == null) return null;
    return Profile.fromMap(row);
  }

  Future<int> incrementPoints() async {
    final result = await _client.rpc('increment_points');
    if (result is! num) {
      throw const FormatException('Supabase returned an invalid points value.');
    }
    return result.toInt();
  }

  Future<List<TeamSummary>> getTeamSummary() async {
    final result = await _client.rpc('get_team_summary');
    if (result is! List) {
      throw const FormatException('Supabase returned an invalid team summary.');
    }
    return result
        .map((row) => TeamSummary.fromMap(Map<String, dynamic>.from(row as Map)))
        .toList();
  }

  Future<List<WithdrawMethod>> getWithdrawMethods() async {
    final rows = await _client
        .from('withdraw_methods')
        .select('code, label')
        .eq('is_active', true)
        .order('label');
    return (rows as List)
        .map((row) => WithdrawMethod.fromMap(Map<String, dynamic>.from(row as Map)))
        .toList();
  }

  Future<List<WithdrawRequest>> getWithdrawHistory() async {
    final user = currentUser;
    if (user == null) return [];

    final rows = await _client
        .from('withdraw_requests')
        .select()
        .eq('user_id', user.id)
        .order('created_at', ascending: false);
    return (rows as List)
        .map((row) => WithdrawRequest.fromMap(Map<String, dynamic>.from(row as Map)))
        .toList();
  }

  Future<List<WithdrawRequest>> getAllWithdrawRequests() async {
    final rows = await _client
        .from('withdraw_requests')
        .select()
        .order('created_at', ascending: false);
    return (rows as List)
        .map((row) => WithdrawRequest.fromMap(Map<String, dynamic>.from(row as Map)))
        .toList();
  }

  Future<WithdrawRequest> requestWithdrawal({
    required String methodCode,
    required String accountNumber,
    required int amountPkr,
  }) async {
    final result = await _client.rpc(
      'request_withdrawal',
      params: {
        'p_method_code': methodCode,
        'p_account_number': accountNumber,
        'p_amount_pkr': amountPkr,
      },
    );
    if (result is! Map) {
      throw const FormatException('Supabase returned an invalid withdrawal request.');
    }
    return WithdrawRequest.fromMap(Map<String, dynamic>.from(result));
  }

  Future<WithdrawRequest> approveWithdrawalRequest(String requestId) async {
    final result = await _client.rpc(
      'approve_withdrawal_request',
      params: {'p_request_id': requestId},
    );
    if (result is! Map) {
      throw const FormatException('Supabase returned an invalid approved request.');
    }
    return WithdrawRequest.fromMap(Map<String, dynamic>.from(result));
  }

  Future<WithdrawRequest> markWithdrawalPaid(String requestId) async {
    final result = await _client.rpc(
      'mark_withdrawal_paid',
      params: {'p_request_id': requestId},
    );
    if (result is! Map) {
      throw const FormatException('Supabase returned an invalid paid request.');
    }
    return WithdrawRequest.fromMap(Map<String, dynamic>.from(result));
  }

  Future<WithdrawRequest> rejectWithdrawalRequest(String requestId) async {
    final result = await _client.rpc(
      'reject_withdrawal_request',
      params: {'p_request_id': requestId},
    );
    if (result is! Map) {
      throw const FormatException('Supabase returned an invalid rejected request.');
    }
    return WithdrawRequest.fromMap(Map<String, dynamic>.from(result));
  }

  Future<void> signOut() => _client.auth.signOut();
}