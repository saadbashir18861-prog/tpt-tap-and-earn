class TeamSummary {
  const TeamSummary({
    required this.level,
    required this.memberCount,
    required this.earning,
  });

  final String level;
  final int memberCount;
  final num earning;

  factory TeamSummary.fromMap(Map<String, dynamic> map) {
    return TeamSummary(
      level: map['level'] as String,
      memberCount: (map['member_count'] as num?)?.toInt() ?? 0,
      earning: (map['earning'] as num?) ?? 0,
    );
  }
}