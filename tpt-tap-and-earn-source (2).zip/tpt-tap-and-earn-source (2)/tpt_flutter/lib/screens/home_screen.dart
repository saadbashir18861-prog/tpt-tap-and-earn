import 'package:flutter/material.dart';

import '../models/profile.dart';
import '../services/supabase_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _service = SupabaseService();
  int _points = 0;
  int _sessionTaps = 0;
  bool _isLoading = true;
  bool _isTapping = false;
  int _coinAnimationId = 0;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    try {
      final profile = await _service.getProfile();
      if (!mounted) return;
      setState(() {
        _points = profile?.points ?? 0;
        _isLoading = false;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _error = 'Could not load your points. Pull to try again.';
        });
      }
    }
  }

  Future<void> _tap() async {
    if (_isTapping) return;

    setState(() {
      _isTapping = true;
      _error = null;
    });

    try {
      final updatedPoints = await _service.incrementPoints();
      if (!mounted) return;
      setState(() {
        _points = updatedPoints;
        _sessionTaps += 1;
        _coinAnimationId += 1;
      });
    } catch (_) {
      if (mounted) {
        setState(() => _error = 'That tap did not save. Please try again.');
      }
    } finally {
      if (mounted) setState(() => _isTapping = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = _service.currentUser;
    final firstName = user?.email?.split('@').first ?? 'there';
    final displayName = firstName.isEmpty ? 'there' : firstName;

    return RefreshIndicator(
      onRefresh: _loadProfile,
      color: Theme.of(context).colorScheme.primary,
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          SliverAppBar(
            pinned: true,
            expandedHeight: 124,
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: const EdgeInsets.fromLTRB(24, 0, 24, 16),
              title: Text(
                'Hey, $displayName',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                _PointsCard(
                  points: _points,
                  isLoading: _isLoading,
                  sessionTaps: _sessionTaps,
                ),
                const SizedBox(height: 28),
                Text(
                  'Make it count',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w800,
                      ),
                ),
                const SizedBox(height: 5),
                Text(
                  'Every tap adds one coin to your account.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: const Color(0xFF6B7A75),
                      ),
                ),
                const SizedBox(height: 28),
                Center(
                  child: SizedBox(
                    width: 208,
                    height: 250,
                    child: Stack(
                      clipBehavior: Clip.none,
                      alignment: Alignment.bottomCenter,
                      children: [
                        _TapButton(
                          onPressed: _tap,
                          isLoading: _isTapping,
                        ),
                        if (_coinAnimationId > 0)
                          Positioned(
                            key: ValueKey(_coinAnimationId),
                            top: 0,
                            left: 0,
                            right: 0,
                            child: const _CoinReward(),
                          ),
                      ],
                    ),
                  ),
                ),
                if (_error != null) ...[
                  const SizedBox(height: 24),
                  _ErrorMessage(message: _error!),
                ],
              ]),
            ),
          ),
        ],
      ),
    );
  }
}

class _PointsCard extends StatelessWidget {
  const _PointsCard({
    required this.points,
    required this.isLoading,
    required this.sessionTaps,
  });

  final int points;
  final bool isLoading;
  final int sessionTaps;

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF123B36), Color(0xFF116E5E)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(
            color: primary.withValues(alpha: 0.16),
            blurRadius: 24,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(
              Icons.monetization_on_rounded,
              color: Color(0xFFB6F7E8),
              size: 28,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                    'TOTAL COINS',
                  style: TextStyle(
                    color: Color(0xFFA9D6CB),
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.6,
                  ),
                ),
                const SizedBox(height: 4),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 220),
                  transitionBuilder: (child, animation) =>
                      ScaleTransition(scale: animation, child: child),
                  child: isLoading
                      ? const SizedBox(
                          key: ValueKey('loading'),
                          width: 28,
                          height: 28,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : Text(
                          '$points',
                          key: ValueKey(points),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 34,
                            fontWeight: FontWeight.w900,
                            height: 1.05,
                          ),
                        ),
                ),
              ],
            ),
          ),
          if (sessionTaps > 0)
            Text(
              '+$sessionTaps today',
              style: const TextStyle(
                color: Color(0xFFB6F7E8),
                fontWeight: FontWeight.w700,
              ),
            ),
        ],
      ),
    );
  }
}

class _TapButton extends StatelessWidget {
  const _TapButton({
    required this.onPressed,
    required this.isLoading,
  });

  final VoidCallback onPressed;
  final bool isLoading;

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Semantics(
      button: true,
       label: 'Tap to earn one coin',
      child: GestureDetector(
        onTap: isLoading ? null : onPressed,
        child: AnimatedScale(
          scale: isLoading ? 0.96 : 1,
          duration: const Duration(milliseconds: 100),
          child: Container(
            width: 208,
            height: 208,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: primary,
              boxShadow: [
                BoxShadow(
                  color: primary.withValues(alpha: 0.18),
                  blurRadius: 0,
                  spreadRadius: 18,
                ),
                BoxShadow(
                  color: primary.withValues(alpha: 0.32),
                  blurRadius: 28,
                  offset: const Offset(0, 16),
                ),
              ],
            ),
            child: Center(
              child: isLoading
                  ? const CircularProgressIndicator(color: Colors.white, strokeWidth: 3)
                  : const Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.touch_app_rounded, color: Colors.white, size: 45),
                        SizedBox(height: 7),
                        Text(
                          'TAP',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 30,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 2,
                          ),
                        ),
                        SizedBox(height: 3),
                        Text(
                           '+1 COIN',
                          style: TextStyle(
                            color: Color(0xFFC9FFF3),
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 1.2,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}

class _CoinReward extends StatefulWidget {
  const _CoinReward();

  @override
  State<_CoinReward> createState() => _CoinRewardState();
}

class _CoinRewardState extends State<_CoinReward>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _opacity;
  late final Animation<double> _scale;
  late final Animation<Offset> _position;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 820),
    );
    _opacity = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0, end: 1), weight: 18),
      TweenSequenceItem(tween: ConstantTween(1), weight: 42),
      TweenSequenceItem(tween: Tween(begin: 1, end: 0), weight: 40),
    ]).animate(_controller);
    _scale = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween(begin: 0.72, end: 1.08),
        weight: 35,
      ),
      TweenSequenceItem(
        tween: Tween(begin: 1.08, end: 1),
        weight: 65,
      ),
    ]).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
    );
    _position = Tween<Offset>(
      begin: const Offset(0, 0.4),
      end: const Offset(0, -0.8),
    ).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
    );
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SlideTransition(
      position: _position,
      child: FadeTransition(
        opacity: _opacity,
        child: ScaleTransition(
          scale: _scale,
          child: Align(
            alignment: Alignment.center,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: const Color(0xFFFFF3D6),
                borderRadius: BorderRadius.circular(18),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x332C7A68),
                    blurRadius: 14,
                    offset: Offset(0, 7),
                  ),
                ],
              ),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 13, vertical: 8),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.monetization_on_rounded,
                      color: Color(0xFFB47B14),
                      size: 20,
                    ),
                    SizedBox(width: 6),
                    Text(
                      '+1 COIN',
                      style: TextStyle(
                        color: Color(0xFF8F6412),
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ErrorMessage extends StatelessWidget {
  const _ErrorMessage({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.cloud_off_rounded, size: 18, color: Color(0xFFB64242)),
        const SizedBox(width: 8),
        Flexible(
          child: Text(
            message,
            style: const TextStyle(color: Color(0xFFB64242)),
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }
}